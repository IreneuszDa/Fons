# Ocena źródeł w 10 ustalonych z góry próbach z DOCX
Sprawdzono pierwszą pozycję answer.evidence wraz z metadanymi recenzji, wszystkie widoczne fragmenty i pełne wskazane publikacje. Każda odpowiedź z tej tabeli pochodzi z rzeczywistego, niezależnego wywołania WWW dla wydania engine-2026.11.22-24-subject-scope. Pełne zapisy są w poprawki-www. D nie wchodzi do mianownika, ponieważ prawidłową odpowiedzią był brak źródła. W dziewięciu pozostałych raportach pokazano 19 pozycji dowodowych. Kilka przykładów korzysta z tej samej publikacji Demagoga.

| Sprawa | Pierwszy fragment uzasadnia zasadniczy wniosek | Komplet widocznych fragmentów | Komplet z otwarciem źródeł | Uzasadnienie |
|---|---|---|---|---|
| A1 | Tak | Tak | Tak | Pierwszy fragment dotyczy przywrócenia depeszy. Drugi uściśla ciągłość dostępu dla abonentów, trzeci identyfikuje nagłówek. |
| A2 | Tak | Tak | Tak | Sky TG24 opisał demonstracje i utrudnienia w dniu przeprowadzonego 24-godzinnego strajku. |
| B | Tak | Tak | Tak | Opis sprawdzenia wydawcy rozpoznaje materiał i datuje go na marzec 2021 r. |
| C | Częściowo | Tak | Tak | Pierwsza pozycja z miasta potwierdza 650 mln i rok. Dalsze fragmenty pozwalają odróżnić szacunek 700 mln i zakres oceny całej wypowiedzi. |
| D | Prawidłowa abstencja | Poza mianownikiem | Poza mianownikiem | Brak podstaw do ustalenia miejscowej taryfy i wskazanie regulaminu jako potrzebnego dowodu. |
| E, kontrola neutralna | Tak | Tak | Tak | Ustalenie wymienia miasta oferujące tę samą ulgę. |
| F | Tak | Tak | Tak | Pierwszy fragment recenzji pokazuje los depeszy i identyfikuje publikację. Uzupełnienie odróżnia słowa autora od oceny redakcji. |
| G | Tak | Tak | Tak | Pierwsze ustalenie o Bydgoszczy, Toruniu i Lublinie wystarcza do obalenia tezy o wyjątkowości Wrocławia. |
| I+ | Częściowo | Częściowo | Tak | Nagłówek i data PAP w pierwszej pozycji identyfikują depeszę. Aby potwierdzić dokładne odesłanie do niej z recenzji, trzeba otworzyć wskazaną publikację Demagoga. |
| J+ | Tak | Tak | Tak | Dane recenzji pochodzą z indeksu Google, a pierwszy cytat wymienia inne miasta. |

Łącznie 7/9 dla pierwszej pozycji, 8/9 dla widocznego kompletu oraz 9/9 po otwarciu źródła. Odrębna stała próba dziesięciu spraw z etykietą zawiera inne pytania i została opisana w ocena-stala-proba.md.
