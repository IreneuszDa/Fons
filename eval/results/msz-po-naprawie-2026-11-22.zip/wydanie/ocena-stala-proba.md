# Czy pierwszy dowód uzasadnia werdykt? Stała próba dziesięciu tez

**Pierwszy fragment uzasadnił rozstrzygnięcie w 8/10 z góry wybranych spraw.** Liczba rozstrzygnięć wyniosła 8, liczba wstrzymań 2. Pierwszy fragment był wystarczający w 8/8 rozstrzygniętych spraw z cytatem. Cały zestaw cytowanych materiałów uzasadnił rozstrzygnięcie w 8/10.

22 listopada 2026 r. sprawdzono dokładnie te same identyfikatory z pierwotnego pliku oceny. W pierwszym pomiarze pierwszy dowód wystarczył w 7/10 spraw, cały zestaw w 8/10. Wtedy rozstrzygnięto wszystkie dziesięć spraw. Obecne zestawienie zachowuje wszystkie identyfikatory, również przy późniejszym wstrzymaniu oceny.

W pomiarze pośrednim na wersji -22 uzyskano 7/10 dla pierwszego dowodu, 7/10 dla całego zestawu i jedno wstrzymanie. Poniżej przedstawiono ręczny odczyt raportów z wersji wydaniowej -24 na tej samej próbie.

Źródło danych to `live100.json`, wersja `engine-2026.11.22-24-subject-scope`, migawka `69ea00d5d845a29b6dc4a052a034e7524bfd4eaf2789f2507df7f036b470cf9a`. Dla każdej tezy odczytano pierwszy niepusty fragment spośród `report.verdicts` dla głównej tezy, jego wydawcę, datę oraz tytuł. Oceniono, czy sam ten materiał obejmuje podmiot, zakres i czas faktycznego werdyktu. W ocenie łącznej użyto wyłącznie fragmentów widocznych w tym samym raporcie. Dane strukturalne oceniono według treści pól. Źródło znalezione osobno nie podwyższa wyniku.

To celowa próba referencyjna obejmująca fakty, które poprzednia wersja rozstrzygnęła. Nie wyznacza dokładności wszystkich cytatów w produkcie.

| Sprawa | Teza | Werdykt silnika | Pierwszy dowód wystarcza | Cały zestaw wystarcza |
|---|---|---|---|---|
| V2-A01 | Finlandia przystąpiła do NATO 4 kwietnia 2023 roku. | POTWIERDZONE | Tak | Tak |
| V2-A02 | Polska sprawowała prezydencję w Radzie Unii Europejskiej w pierwszej połowie 2025 roku. | BRAK_DOWODOW | Wstrzymanie | Wstrzymanie |
| V2-A03 | Status państwa kandydującego do UE Ukraina uzyskała latem 2022 roku. | BRAK_DOWODOW | Wstrzymanie | Wstrzymanie |
| V2-A06 | Artykuł 5 Traktatu Północnoatlantyckiego został uruchomiony tylko raz, po zamachach z 11 września 2001 roku. | POTWIERDZONE | Tak | Tak |
| V2-A07 | Od 1 stycznia 2025 roku Bułgaria i Rumunia są w pełni w strefie Schengen. | POTWIERDZONE | Tak | Tak |
| V2-A08 | Polska jest członkiem Unii Europejskiej od 1 maja 2004 roku. | POTWIERDZONE | Tak | Tak |
| V2-A09 | Turcja nie jest członkiem Unii Europejskiej. | POTWIERDZONE | Tak | Tak |
| V2-A10 | Ukraina jest członkiem NATO od 2024 roku. | FALSZYWE | Tak | Tak |
| V2-A11 | Polska przyjęła euro jako swoją walutę w 2024 roku. | FALSZYWE | Tak | Tak |
| V2-A13 | Wybory prezydenckie w Polsce w 2025 roku wygrał Rafał Trzaskowski. | FALSZYWE | Tak | Tak |

## V2-A01

Pierwszy odczyt danych NATO wskazuje Finlandię i pełną datę członkostwa, 4 kwietnia 2023 r. To wystarcza do potwierdzenia; dalsze fragmenty obejmują także informacje gov.pl, które podają pełną datę.

Pierwszy fragment raportu pochodzi z rekordu `nato:9f175c6af977`. [NATO: członkowie przyjęci w 2023 r. — Finlandia](https://www.nato.int/en/about-us/organization/nato-member-countries)

Identyfikatory fragmentów w raporcie  ·  `nato:9f175c6af977`, `nato:bf9775d132ea`, `nato:7001a3734fd9`, `live:48129b4746c226f4e6db`, `live:5a72d1671ae9f4c725e7`.

## V2-A02

Silnik wstrzymał ocenę i oznaczył fragment profilu UE jako częściowy. Profil wymienia polską prezydencję w okresie od stycznia do czerwca 2025 r. Data publikacji w raporcie przypada jednak na 11 grudnia 2024 r., przed prezydencją. Odczyt potwierdza terminarz, ale ma ograniczenie przy ocenie późniejszej realizacji. Wstrzymanie pozostało osobną kategorią.

Pierwszy fragment raportu pochodzi z rekordu `live:f43c323272bfe3fa98c2`. [Polska – Informacje o kraju UE | Unia Europejska](https://european-union.europa.eu/principles-countries-history/eu-countries/poland_pl)

Identyfikatory fragmentów w raporcie  ·  `live:f43c323272bfe3fa98c2`.

## V2-A03

Silnik pozostawił sprawę bez werdyktu rozstrzygającego. Odczyt danych podaje czerwiec 2022 r. Zgodnie z przyjętym kalendarzowym rozumieniem lata sam miesiąc nie wskazuje, czy zdarzenie nastąpiło po początku lata. Rada Europejska podaje 23 czerwca, jednak tego dokładniejszego materiału nie pokazano w raporcie.

Pierwszy fragment raportu pochodzi z rekordu `eu-portal:9ce4a9d60272`. [Unia Europejska: Ukraina — kraj kandydujący do UE (daty wniosku i statusu kandydata)](https://european-union.europa.eu/principles-countries-history/eu-enlargement_pl)

Porównanie dotyczyło również materiału pierwotnego. [Źródło kontrolne](https://www.consilium.europa.eu/en/press/press-releases/2022/06/23/european-council-conclusions-on-ukraine-the-membership-applications-of-ukraine-the-republic-of-moldova-and-georgia-western-balkans-and-external-relations-23-june-2022/)

Identyfikatory fragmentów w raporcie  ·  `eu-portal:9ce4a9d60272`.

## V2-A06

NATO podaje, że po zamachach z 11 września 2001 r. po raz pierwszy i jedyny zastosowało art. 5. Zgadza się zarówno zdarzenie, jak i liczba uruchomień.

Pierwszy fragment raportu pochodzi z rekordu `nato:b49e21c2a8f2`. [NATO: Collective defence and Article 5 (cz. 2)](https://www.nato.int/en/what-we-do/introduction-to-nato/collective-defence-and-article-5)

Identyfikatory fragmentów w raporcie  ·  `nato:b49e21c2a8f2`, `live:759ee994c64da8ac1e15`, `live:34d3d04698bde700bb0c`, `live:9cc313ad5503a2afe843`, `demagog:16900a899311`.

## V2-A07

Pierwszy fragment KE, opublikowany 3 stycznia 2025 r., wskazuje oba państwa, datę 1 stycznia i uzyskanie pełnego członkostwa w Schengen po zniesieniu kontroli lądowych. Następny fragment wprost podaje także rok. Wzmianki o 2024 r. odnoszą się do wcześniejszego etapu.

Pierwszy fragment raportu pochodzi z rekordu `ec-home-affairs:158b8c650e16`. [Komisja Europejska: Bulgaria and Romania join the Schengen Area (Bułgaria i Rumunia w strefie Schengen od 1 stycznia 2025) (cz. 1)](https://home-affairs.ec.europa.eu/news/bulgaria-and-romania-join-schengen-area-2025-01-03_en)

Identyfikatory fragmentów w raporcie  ·  `ec-home-affairs:158b8c650e16`, `ec-home-affairs:bccddac4e13d`, `eu-portal:05eede190471`, `eu-portal:bd6509bc4de3`, `eu-portal:36426952386b`.

## V2-A08

Oficjalny profil Polski w UE podaje 1 maja 2004 r. jako początek członkostwa. Drugi odczyt danych wskazuje tę samą pełną datę i umieszcza Polskę wśród dziesięciu krajów rozszerzenia.

Pierwszy fragment raportu pochodzi z rekordu `eu-portal:5761499f864c`. [Unia Europejska: Polska — informacje o kraju UE](https://european-union.europa.eu/principles-countries-history/eu-countries/poland_pl)

Identyfikatory fragmentów w raporcie  ·  `eu-portal:5761499f864c`, `eu-portal:102673732ae5`.

## V2-A09

Odczyt portalu UE oznacza Turcję jako aktualnego kandydata. Kandydat do członkostwa nie jest obecnym członkiem. Rok nadania statusu i rozpoczęcia negocjacji stanowią dodatkowe informacje.

Pierwszy fragment raportu pochodzi z rekordu `eu-portal:1c5a9bd2f018`. [Unia Europejska: Turcja — kraj kandydujący do UE (daty wniosku i statusu kandydata)](https://european-union.europa.eu/principles-countries-history/eu-enlargement_pl)

Porównanie dotyczyło również materiału pierwotnego. [Źródło kontrolne](https://enlargement.ec.europa.eu/countries/turkiye_en)

Identyfikatory fragmentów w raporcie  ·  `eu-portal:1c5a9bd2f018`.

## V2-A10

Publikacja NATO z października 2026 r. opisuje członkostwo Ukrainy jako cel, do którego sojusznicy nadal prowadzą ten kraj. To wyklucza twierdzenie o nieprzerwanym członkostwie od 2024 r. Oceniając fragment, uwzględniono datę publikacji.

Pierwszy fragment raportu pochodzi z rekordu `nato:9e7d7e9ee13d`. [NATO: Relations with Ukraine (cz. 2)](https://www.nato.int/en/what-we-do/partnerships-and-cooperation/relations-with-ukraine)

Porównanie dotyczyło również materiału pierwotnego. [Źródło kontrolne](https://nato.int/en/what-we-do/partnerships-and-cooperation/natos-support-for-ukraine)

Identyfikatory fragmentów w raporcie  ·  `nato:9e7d7e9ee13d`.

## V2-A11

Profil UE wciąż wymienia złotego jako walutę Polski i opisuje przyjęcie euro jako przygotowywaną zmianę. Fragment obala twierdzenie o wprowadzeniu euro w 2024 r.

Pierwszy fragment raportu pochodzi z rekordu `eu-portal:5761499f864c`. [Unia Europejska: Polska — informacje o kraju UE](https://european-union.europa.eu/principles-countries-history/eu-countries/poland_pl)

Identyfikatory fragmentów w raporcie  ·  `eu-portal:5761499f864c`, `eu-portal:92dbb09f38fe`, `demagog:cbddd95ce72d`.

## V2-A13

Końcowe obwieszczenie PKW z 2 czerwca 2025 r. identyfikuje Karola Nawrockiego jako wybranego prezydenta. To jednoznacznie obala zwycięstwo Rafała Trzaskowskiego w tych wyborach.

Pierwszy fragment raportu pochodzi z rekordu `sejm-eli:e9241009f1ef`. [Obwieszczenie Państwowej Komisji Wyborczej z dnia 2 czerwca 2025 r. o wynikach ponownego głosowania i wyniku wyborów Prezydenta Rzeczypospolitej Polskiej (Dz.U. 2025 poz. 714) (cz. 3)](https://api.sejm.gov.pl/eli/acts/DU/2025/714/text/O/D20250714.pdf)

Identyfikatory fragmentów w raporcie  ·  `sejm-eli:e9241009f1ef`, `sejm-eli:2d656810cb81`.