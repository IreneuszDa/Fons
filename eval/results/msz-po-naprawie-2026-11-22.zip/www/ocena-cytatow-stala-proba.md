# Czy pierwszy dowód uzasadnia werdykt? Stała próba dziesięciu tez

**Pierwszy fragment uzasadnił rozstrzygnięcie w 7/10 z góry wybranych spraw.** Liczba rozstrzygnięć wyniosła 9, liczba wstrzymań 1. Pierwszy fragment był wystarczający w 7/9 rozstrzygniętych spraw z cytatem. Cały zestaw cytowanych materiałów uzasadnił rozstrzygnięcie w 7/10.

22 listopada 2026 r. sprawdzono dokładnie te same identyfikatory z pierwotnego pliku oceny. W pierwszym pomiarze pierwszy dowód wystarczył w 7/10 spraw, cały zestaw w 8/10. Wtedy rozstrzygnięto wszystkie dziesięć spraw. Obecne zestawienie zachowuje wszystkie identyfikatory, również przy późniejszym wstrzymaniu oceny.

Źródło danych to `live100.json`, wersja `engine-2026.11.22-22-grounded-evidence`, migawka `69ea00d5d845a29b6dc4a052a034e7524bfd4eaf2789f2507df7f036b470cf9a`. Dla każdej tezy odczytano pierwszy niepusty fragment spośród `report.verdicts` dla głównej tezy, jego wydawcę, datę oraz tytuł. Oceniono, czy sam ten materiał obejmuje podmiot, zakres i czas faktycznego werdyktu. W ocenie łącznej użyto wyłącznie fragmentów widocznych w tym samym raporcie. Dane strukturalne oceniono według treści pól. Źródło znalezione osobno nie podwyższa wyniku.

To celowa próba referencyjna obejmująca fakty, które poprzednia wersja rozstrzygnęła. Nie wyznacza dokładności wszystkich cytatów w produkcie.

| Sprawa | Teza | Werdykt silnika | Pierwszy dowód wystarcza | Cały zestaw wystarcza |
|---|---|---|---|---|
| V2-A01 | Finlandia przystąpiła do NATO 4 kwietnia 2023 roku. | POTWIERDZONE | Tak | Tak |
| V2-A02 | Polska sprawowała prezydencję w Radzie Unii Europejskiej w pierwszej połowie 2025 roku. | BRAK_DOWODOW | Wstrzymanie | Wstrzymanie |
| V2-A03 | Status państwa kandydującego do UE Ukraina uzyskała latem 2022 roku. | POTWIERDZONE | Nie | Nie |
| V2-A06 | Artykuł 5 Traktatu Północnoatlantyckiego został uruchomiony tylko raz, po zamachach z 11 września 2001 roku. | POTWIERDZONE | Tak | Tak |
| V2-A07 | Od 1 stycznia 2025 roku Bułgaria i Rumunia są w pełni w strefie Schengen. | POTWIERDZONE | Tak | Tak |
| V2-A08 | Polska jest członkiem Unii Europejskiej od 1 maja 2004 roku. | POTWIERDZONE | Nie | Nie |
| V2-A09 | Turcja nie jest członkiem Unii Europejskiej. | POTWIERDZONE | Tak | Tak |
| V2-A10 | Ukraina jest członkiem NATO od 2024 roku. | FALSZYWE | Tak | Tak |
| V2-A11 | Polska przyjęła euro jako swoją walutę w 2024 roku. | FALSZYWE | Tak | Tak |
| V2-A13 | Wybory prezydenckie w Polsce w 2025 roku wygrał Rafał Trzaskowski. | FALSZYWE | Tak | Tak |

## V2-A01

Pierwszy odczyt danych NATO identyfikuje Finlandię i pełną datę jej członkostwa, 4 kwietnia 2023 r. Drugi odczyt powtarza informację z tej samej strony.

Pierwszy fragment raportu pochodzi z rekordu `nato:9f175c6af977`. [NATO: członkowie przyjęci w 2023 r. — Finlandia](https://www.nato.int/en/about-us/organization/nato-member-countries)

Identyfikatory fragmentów w raporcie  ·  `nato:9f175c6af977`, `nato:bf9775d132ea`.

## V2-A02

Silnik wstrzymał werdykt i nie wyświetlił cytatu potwierdzającego półrocze prezydencji. W poprzednim pomiarze ta sama sprawa miała rozstrzygnięcie i cytat.

W raporcie nie pokazano cytatu dla głównej tezy.

## V2-A03

Odczyt UE podaje miesiąc uzyskania statusu kandydata. Część czerwca przypada przed początkiem kalendarzowego lata. Do potwierdzenia pełnego zakresu tezy potrzebna jest data dzienna. Rada Europejska wydała decyzję 23 czerwca 2022 r., ale ten dokument nie występuje wśród dowodów raportu. Przy meteorologicznej definicji lata ocena fragmentu zmieniłaby się na pozytywną.

Pierwszy fragment raportu pochodzi z rekordu `eu-portal:9ce4a9d60272`. [Unia Europejska: Ukraina — kraj kandydujący do UE (daty wniosku i statusu kandydata)](https://european-union.europa.eu/principles-countries-history/eu-enlargement_pl)

Porównanie dotyczyło również materiału pierwotnego. [Źródło kontrolne](https://www.consilium.europa.eu/en/press/press-releases/2022/06/23/european-council-conclusions-on-ukraine-the-membership-applications-of-ukraine-the-republic-of-moldova-and-georgia-western-balkans-and-external-relations-23-june-2022/)

Identyfikatory fragmentów w raporcie  ·  `eu-portal:9ce4a9d60272`.

## V2-A06

NATO podaje, że po zamachach z 11 września 2001 r. po raz pierwszy i jedyny zastosowało art. 5. Zgadza się zarówno zdarzenie, jak i liczba uruchomień.

Pierwszy fragment raportu pochodzi z rekordu `nato:b49e21c2a8f2`. [NATO: Collective defence and Article 5 (cz. 2)](https://www.nato.int/en/what-we-do/introduction-to-nato/collective-defence-and-article-5)

Identyfikatory fragmentów w raporcie  ·  `nato:b49e21c2a8f2`, `nato:4c6f79a454c2`.

## V2-A07

Pierwszy fragment KE, opublikowany 3 stycznia 2025 r., wskazuje oba państwa, datę 1 stycznia i uzyskanie pełnego członkostwa w Schengen po zniesieniu kontroli lądowych. Następny fragment wprost podaje także rok. Wzmianki o 2024 r. odnoszą się do wcześniejszego etapu.

Pierwszy fragment raportu pochodzi z rekordu `ec-home-affairs:158b8c650e16`. [Komisja Europejska: Bulgaria and Romania join the Schengen Area (Bułgaria i Rumunia w strefie Schengen od 1 stycznia 2025) (cz. 1)](https://home-affairs.ec.europa.eu/news/bulgaria-and-romania-join-schengen-area-2025-01-03_en)

Identyfikatory fragmentów w raporcie  ·  `ec-home-affairs:158b8c650e16`, `ec-home-affairs:bccddac4e13d`, `eu-portal:05eede190471`, `eu-portal:36426952386b`.

## V2-A08

Jedyny fragment podaje rok przyjęcia Polski do UE. Teza użytkownika wskazuje także dzień i miesiąc. Pierwszy i zarazem jedyny cytowany fragment nie pozwala ustalić 1 maja.

Pierwszy fragment raportu pochodzi z rekordu `eu-portal:30c6faa24471`. [Unia Europejska: Polska — członkostwo w UE, strefie euro i strefie Schengen](https://european-union.europa.eu/principles-countries-history/eu-countries_pl)

Identyfikatory fragmentów w raporcie  ·  `eu-portal:30c6faa24471`.

## V2-A09

Odczyt portalu UE oznacza Turcję jako aktualnego kandydata. Kandydat do członkostwa nie jest obecnym członkiem. Rok nadania statusu i rozpoczęcia negocjacji stanowią dodatkowe informacje.

Pierwszy fragment raportu pochodzi z rekordu `eu-portal:1c5a9bd2f018`. [Unia Europejska: Turcja — kraj kandydujący do UE (daty wniosku i statusu kandydata)](https://european-union.europa.eu/principles-countries-history/eu-enlargement_pl)

Porównanie dotyczyło również materiału pierwotnego. [Źródło kontrolne](https://enlargement.ec.europa.eu/countries/turkiye_en)

Identyfikatory fragmentów w raporcie  ·  `eu-portal:1c5a9bd2f018`.

## V2-A10

Publikacja NATO z października 2026 r. opisuje członkostwo Ukrainy jako cel, do którego sojusznicy nadal prowadzą ten kraj. To wyklucza twierdzenie o nieprzerwanym członkostwie od 2024 r. Oceniając fragment, uwzględniono datę publikacji.

Pierwszy fragment raportu pochodzi z rekordu `nato:9e7d7e9ee13d`. [NATO: Relations with Ukraine (cz. 2)](https://www.nato.int/en/what-we-do/partnerships-and-cooperation/relations-with-ukraine)

Porównanie dotyczyło również materiału pierwotnego. [Źródło kontrolne](https://nato.int/en/what-we-do/partnerships-and-cooperation/natos-support-for-ukraine)

Identyfikatory fragmentów w raporcie  ·  `nato:9e7d7e9ee13d`.

## V2-A11

Profil UE wciąż wymienia złotego jako walutę Polski i opisuje przyjęcie euro jako przygotowywaną zmianę. Fragment obala twierdzenie o wprowadzeniu euro w 2024 r.

Pierwszy fragment raportu pochodzi z rekordu `eu-portal:5761499f864c`. [Unia Europejska: Polska — informacje o kraju UE](https://european-union.europa.eu/principles-countries-history/eu-countries/poland_pl)

Identyfikatory fragmentów w raporcie  ·  `eu-portal:5761499f864c`.

## V2-A13

Końcowe obwieszczenie PKW z 2 czerwca 2025 r. identyfikuje Karola Nawrockiego jako wybranego prezydenta. To jednoznacznie obala zwycięstwo Rafała Trzaskowskiego w tych wyborach.

Pierwszy fragment raportu pochodzi z rekordu `sejm-eli:e9241009f1ef`. [Obwieszczenie Państwowej Komisji Wyborczej z dnia 2 czerwca 2025 r. o wynikach ponownego głosowania i wyniku wyborów Prezydenta Rzeczypospolitej Polskiej (Dz.U. 2025 poz. 714) (cz. 3)](https://api.sejm.gov.pl/eli/acts/DU/2025/714/text/O/D20250714.pdf)

Identyfikatory fragmentów w raporcie  ·  `sejm-eli:e9241009f1ef`.
