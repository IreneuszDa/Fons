# Dosłowność cytatów w korpusie

22 listopada 2026 r. Audyt offline odczytał oryginalne odpowiedzi HTTP i pliki PDF zapisane przez klienta pobrań. Weryfikator usuwa znacznik HTML i normalizuje białe znaki. Osobny odczyt publikacji wymienionych poniżej sprawdza fragmenty, dla których w standardowym cache brakuje kopii.

| Zbiór | Wynik | Co porównano |
|---|---:|---|
| Materiały instytucjonalne | **37/37** | 26 wierszy ZUS, 6 fragmentów Gov.pl, 2 fragmenty HTML i 1 PDF GUS, 1 publikacja EBC i 1 Senatu. Wszystkie fragmenty występują w źródłach. |
| Dokumenty powiązane z publikacjami | **5/6 offline** | Depesza PAP, Wrocław.pl, wystąpienie RPO i dwie relacje Sky TG24. Serwis Odyseusz odmawia klientowi automatycznego pobrania. |
| Dodatkowe cytaty Demagoga | **5/5 w kontroli redakcyjnej**, 0/5 w cache HTML | Porównanie dwóch fragmentów depeszy i trzech fragmentów z pozostałych analiz w publikacjach wydawcy. Google Fact Check Tools zawiera tezy i oceny, pełnych cytatów uzasadnienia nie przechowuje. |

Wszystkie **26/26 par data–kwota** z zestawienia ZUS zgadza się również z osobno odczytanym PDF Ministerstwa Rodziny. Okresy biegną od 1 stycznia 2003 r. do 1 stycznia 2026 r., w tym po dwie stawki w latach 2023 i 2024. [ZUS](https://psz.zus.pl/pl/web/guest/baza-wiedzy/skladki-wskazniki-odsetki/wskazniki/minimalne-wynagrodzenie-za-prace-od-2003-r) · [Ministerstwo Rodziny, tabela do pobrania](https://www.gov.pl/web/rodzina/minimalne-wynagrodzenie-za-prace)

Senat potwierdza uchwalenie Konstytucji 2 kwietnia 1997 r., referendum 25 maja i wejście w życie 17 października. Ministerstwo Sprawiedliwości w cytowanym zdaniu o państwach poza Radą Europy wymienia Białoruś, Stolicę Apostolską i Kosowo. [Senat](https://www.senat.gov.pl/aktualnoscilista/art,14652,25-rocznica-uchwalenia-konstytucji-rp.html) · [Ministerstwo Sprawiedliwości](https://www.gov.pl/web/sprawiedliwosc/prawa-czlowieka-w-radzie-europy)

Niezależny odczyt opublikowanej przez Odyseusza aktualności dla Włoch potwierdził oba fragmenty rozdzielone wielokropkiem i datę aktualizacji 19 listopada 2026 r. Komunikat zapowiadał strajk 20 listopada. Liczbę ponad 100 miast MSZ przypisało planowi CGIL. Automatyczny audyt offline nadal sygnalizuje brak surowej kopii. [Odyseusz MSZ, aktualności](https://odyseusz.gov.pl/)

W czterech publikacjach Demagoga potwierdzono dwa fragmenty o przywróceniu depeszy i dostępie odbiorców CSI, fragment o darmowych przejazdach w trzech innych miastach, kwotę 650 mln zł oraz datowanie filmu na marzec 2021 r. [Depesza PAP](https://demagog.org.pl/wypowiedzi/donald-tusk-uspokajal-przed-powodzia-depesza-pap-nie-zniknela/) · [Ulgi](https://demagog.org.pl/wypowiedzi/darmowa-komunikacja-dla-65-latkow-tylko-we-wroclawiu-sprawdzamy/) · [Koszty transportu](https://demagog.org.pl/wypowiedzi/darmowa-komunikacja-jaka-kwote-musialby-dolozyc-wroclaw/) · [Nagranie sprzed TK](https://demagog.org.pl/wypowiedzi/policja-zaslania-protestujacych-parawanem-wos-udostepnia-stare-nagranie/)

Pełny proces `npm run corpus:verify` trwał **32,15 s**. Główna kontrola porównała 1600 rekordów, zgłosiła jeden brak surowego źródła i pozostawiła 2074 rekordy do innych sposobów weryfikacji. Osobne przebiegi potwierdziły 455 rekordów EUvsDisinfo i 189/189 rekordów z feedu ClaimReview, bez rozbieżności. Kod wyjścia pełnego procesu wyniósł 1 z powodu brakującej kopii Odyseusza. Przed poprawką główna kontrola porównywała 1565 rekordów i pomijała 2110. [Pełny log po zmianie](corpus-verify-after.log) · [Czas](corpus-verify-time.log) · [Log wcześniejszy](corpus-verify.log)
