from pathlib import Path
import sys,time,json,urllib.request as U,urllib.error as E,http.cookiejar as C,base64,concurrent.futures,datetime
dir=Path(__file__).resolve().parent
cases={
'A1':'Czy PAP usunęła depeszę o wypowiedzi Donalda Tuska przed powodzią z 13 września 2024 r.?',
'A2':'Czy we Włoszech ostatnio odbywał się strajk generalny?',
'B':'Czy film udostępniony przez Michała Wosia 14 września 2026 r. pokazywał ówczesny protest pod Trybunałem Konstytucyjnym? https://www.tiktok.com/@mwospl/video/7685116354155826465',
'C':'Czy Wrocław wydaje na komunikację około 700 mln zł. Dlaczego w analizie Demagoga jest 650 mln zł?',
'D':'Czy od wczoraj w Pcimiu bilety autobusowe można kupić tylko przez aplikację?',
'E-kontrola':'Czy Wrocław był jedynym miastem, w którym 65-latkowie jeździli za darmo? Sprawdź też tę stronę: https://demagog.org.pl/wypowiedzi/darmowa-komunikacja-dla-65-latkow-tylko-we-wroclawiu-sprawdzamy/',
'F':'Czy Demagog to sprawdzał?',
'G':'Czy Wrocław był jedynym miastem w Polsce, w którym 65-latkowie jeździli komunikacją miejską za darmo?',
'H1':'Czy od przyszłego tygodnia diesle nie będą mogły wjechać do centrum Pcimia?',
'H2':'Czy Pcim wprowadza zakaz wjazdu diesli do centrum?',
'Iplus':'Czy ten wpis dotyczy tej samej depeszy PAP, którą sprawdzał Demagog? https://www.pap.pl/aktualnosci/premier-nie-ma-powodu-do-paniki-prognozy-nie-sa-przesadnie-alarmujace-0',
'Iminus':'Czy ten wpis dotyczy tej samej depeszy PAP, którą sprawdzał Demagog? https://www.pap.pl/aktualnosci/tusk-o-powodzi-byla-najwieksza-ulewa-w-historii-europy-srodkowej-0',
'Jplus':'Czy Demagog sprawdzał, czy Wrocław był jedynym miastem z darmowymi przejazdami dla 65-latków?',
'Jminus':'Czy Demagog sprawdzał, czy Wrocław był jedynym miastem z darmowymi przejazdami dla 65-latków?',
'Jocr':'Czy Demagog to sprawdzał?',
'Audio':'Co zostało powiedziane w tym nagraniu?',
}
cases.update({
'A22-WWW':'Wojsko Polskie oficjalnie walczy na froncie w Ukrainie.',
'Bonus-obraz':'Gdzie wcześniej opublikowano to zdjęcie? Pokaż rzeczywiste dopasowania tej samej fotografii.',
'Multi':'Sprawdź oba twierdzenia osobno. Szwecja przystąpiła do NATO w 2024 roku. Finlandia przystąpiła do NATO w 2024 roku.',
'A2-ANSA':'Czy strajk generalny we Włoszech 20 listopada 2026 r. faktycznie się odbył? Co ustala ten materiał? https://www.ansa.it/sito/notizie/cronaca/2026/11/20/oggi-lo-sciopero-generale.-in-piazza-lavoratori-e-studenti.-landini-ascoltare-le-piazze-non_599c502c-b0d3-44aa-8e7b-cdf04b274aeb.html',
'I-X':'Czy ten wpis dotyczy tej samej depeszy PAP, którą sprawdzał Demagog? https://x.com/JKowalski_posel/status/1835264205106131436',
})
def run(label):
 f=dir/'res'/(label+'.json')
 if f.exists(): return
 txt=cases[label]; port={'Jminus':18864,'Jocr':18865}.get(label,18863); base='http://127.0.0.1:'+str(port); url=base+'/api/chat'
 data={'text':txt}
 if label in ('F','Jocr'): data['image']={'mime':'image/png','base64':base64.b64encode((dir/'source.png').read_bytes()).decode()}
 if label=='Bonus-obraz': data['image']={'mime':'image/jpeg','base64':base64.b64encode((dir/'earth.jpg').read_bytes()).decode()};data['imageOptions']={'searchWeb':True}
 if label=='Audio':
  data['recording']={'mime':'audio/mpeg','base64':base64.b64encode((dir/'source.mp3').read_bytes()).decode()}; url+='/recording'
 t=time.perf_counter(); start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 op=U.build_opener(U.HTTPCookieProcessor(C.CookieJar()))
 try:
  with op.open(U.Request(url,json.dumps(data).encode(),headers={'Content-Type':'application/json'}),timeout=360) as v: code=v.getcode(); resp=json.load(v)
 except E.HTTPError as e:code=e.code; resp=json.loads(e.read())
 except Exception as e:print(label,'ERROR',e,flush=True);return
 rec={'id':label,'question':txt,'started':start,'elapsed':round(time.perf_counter()-t,3),'http':code,'response':resp}
 r=resp.get('reply',{}).get('report') or {}
 if r.get('token'):
  try:
   with op.open(base+'/api/report/'+r['token'],timeout=10) as v:
    back=json.load(v);rec['readback_http']=v.status;rec['readback_same_id']=(back.get('report',back).get('id')==r['id'])
  except Exception as e:rec['readback_error']=str(e)
 f.write_text(json.dumps(rec,ensure_ascii=False,indent=1))
 print(label,code,rec['elapsed'],resp.get('reply',{}).get('kind'),r.get('status'),r.get('mainVerdict'),resp.get('reply',{}).get('textPl','')[:180],flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as p:list(p.map(run,sys.argv[1:]))
