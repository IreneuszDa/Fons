# Odtworzenie pomiaru
W katalogu projektu Fons zainstaluj zależności przez `npm ci`. Skopiuj `.env.example` do `.env` i podaj własne klucze zgodnie z README. Wszystkie sprawdzenia żywe korzystają z faktycznych zewnętrznych usług i mogą generować opłaty. Silnik używa korpusu w repozytorium i lokalnego E5. W pierwszym uruchomieniu biblioteka może pobrać model.

Z katalogu głównego wykonaj `node --import tsx eval/real-text.mjs ./pomiar-fons`. Podaj pusty katalog dla nowej próby. Przerwane uruchomienie można wznowić w jego katalogu z tym samym kodem i tą samą migawką. Plik `live100.json` zawiera stan końcowy, identyfikatory wersji, klucz, wszystkie odpowiedzi, czasy i koszty. Obliczenia i definicje miar pochodzą z `eval/metrics.ts`. Liczby odtwarzają się z dostarczonych raportów. W nowym wywołaniu model, indeks wyszukiwarki i treść stron mogą dać inne wyniki.

Pliki z katalogu www zawierają rzeczywiste pytania wysłane do aplikacji. Można je powtórzyć przez uruchomiony lokalnie czat WWW. Do F i Jocr dołącz source.png, do Audio dołącz source.mp3, do Bonus-obraz dołącz earth.jpg. Wariant Jminus wykorzystuje odizolowaną konfigurację z niedostępnym indeksem Google, a Jocr konfigurację bez poświadczeń modelu OCR. W H użyj dwóch różnych sesji. Dla G wpisz to samo pytanie przez `npm run ask -- "…"`. Programy z katalogu odtworzenie pokazują użyte komunikaty i metodę porównania. Porty 18863–18865 w skrypcie odpowiadają lokalnym serwerom z tych pomiarów.

Pliki JSON usuwają tokeny raportów i identyfikatory sesji, zachowują treść, werdykt, cytaty oraz adresy wydawców. Suma kontrolna każdego załącznika jest w sha256.json. Nagranie działa bez dźwięku dzięki ścieżce napisów. Własne przypadki i klucz projektu zastępują nieudostępniony kompletny pakiet jury.

W katalogu odtworzenie znajduje się osobny ZIP z samodzielnie uruchamialnym serwerem, zbudowanym WWW, danymi i ewaluatorem. W podkatalogu wydanie są wyniki uruchomień wersji końcowej, w tym eksport STIX, porównania CLI i dwa rozmiary ekranu. W archiwum nie ma baz użytkowników, zdjęć makiet ani sekretów.

Część odtworzenie/po-serii zawiera dwa pliki z katalogu roboczego po dodatkowych kontrolach: odczyt załączonego artykułu i kontrolę korpusu. Zapis wydanie/A2-ANSA-po-kontroli-cytatu.json pochodzi z rzeczywistego powtórzenia po poprawce. Liczby dla 100 pytań pozostają przypisane do niezmienionej próby tekstowej.
