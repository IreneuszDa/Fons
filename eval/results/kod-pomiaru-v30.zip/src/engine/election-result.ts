import type { CorpusRecord } from "../shared/contracts";
import { fold } from "./retrieval/stem";

/** A query about winning an election as a whole, as opposed to winning one round. */
export function asksForElectionWinner(query: string): boolean {
  const s = fold(query);
  return /\b(?:wybor\w*|elekcj\w*|election\w*)\b/.test(s)
    && /\b(?:wygr\w*|zwycie\w*|wybran\w*|winner|won|elected)\b/.test(s)
    && !/\b(?:pierwsz\w*|1\.?|i)\s+tur\w*|\bfirst.round\b/.test(s);
}

/** Classify only explicit statements in the body. A bulletin title may occur on every page of the results. */
export function electionResultStage(record: CorpusRecord): "elected" | "runoff_pending" | undefined {
  if (record.role !== "tresc" || record.level !== 1 || !/\b(?:wybor\w*|election\w*)\b/.test(fold(record.title))) return;
  const s = fold(record.text).replace(/\s+/g, " ");
  if (/\b(?:zostal[ai]? wybran[ay]|wybran[ay] zostal[ai]?|(?:was|has been) elected)\b/.test(s)) return "elected";
  if (/\b(?:przeprowadzone zostanie ponowne glosowanie|odbedzie sie (?:ponowne glosowanie|druga tura)|(?:a |the )?runoff will be held)\b/.test(s)) return "runoff_pending";
}
