/**
 * Step 6 (iii) — independent verifier: ONE batched call (verifier provider, fast tier) only for
 * evidence that would be decisive. "sprzeciw" → evidence stops being decisive (excluded
 * "verifier_dissent"); "niepewne" → only lowers strength (handled by the rules module).
 */
import type { Claim, CorpusRecord, EvidenceAssessment, LlmProvider, ModelUsage, VerifierVote } from "../shared/contracts";
import { fence } from "./llm/fence";
import { VERIFIER_SYSTEM, VerifierOut } from "./prompts";
import { isProfileField } from "./retrieval/subject";

/** One batched call; 18 covers 6 claims with up to 3 decisive items each (items are interleaved per claim). */
export const MAX_VERIFIER_ITEMS = 18;

export interface VerifierCandidate {
  claim: Claim;
  assessment: EvidenceAssessment;
  record: CorpusRecord;
}

export function buildVerifierPrompt(items: { ref: string; c: VerifierCandidate }[], checkedAt?: Date): string {
  const parts = ["Oceń każdą pozycję."];
  if (items.some(({c}) => c.record.topics.includes("cpi-yoy") || c.record.topics.includes("nbp-reference"))) {
    parts.push("Głos dotyczy poprawności zaproponowanej relacji. Poprawne obalenie oraz poprawne potwierdzenie otrzymują głos zgoda, błędne przypisanie relacji otrzymuje sprzeciw. Sprawdź, czy to ta sama miara, jednostka, wartość lub próg i właściwy okres. Dla relacji o wartości historycznej oceń wyłącznie podany okres historyczny. Dla twierdzenia o aktualnym wskaźniku publikowanym okresowo ustal, czy cytowany odczyt był ostatnim opublikowanym w dniu sprawdzenia. Data publikacji sama tego nie dowodzi.");
  }
  for (const { ref, c } of items) {
    const body =
      c.record.role === "stala_rola"
        ? `Rodzaj: dopasowanie\nTwierdzenie: ${c.claim.text}\nTeza sprawdzona przez fact-checkerów: ${c.record.claimReviewed ?? c.assessment.quote}\nZaproponowano: ${c.assessment.fixedRoleMatch ?? "niepewne"}`
        : `Rodzaj: relacja\nTwierdzenie: ${c.claim.text}\nCytat: ${c.assessment.quote}\nZaproponowana relacja: ${c.assessment.historicalSupport ? `cytat potwierdza dokładnie ten stan w przeszłości, w okresie ${c.assessment.period ?? "nieustalonym"}` : c.assessment.partialMeaning === "correction" ? "KORYGUJE_CZESC" : c.assessment.relation} (aspekt: ${c.assessment.aspect})`;
    const heading = isProfileField(c.record, c.assessment.quote)
      ? `\nTytuł profilu, do którego należy cytowane pole: ${c.record.title}` : "";
    const rateSeries = c.record.topics.includes("cpi-yoy") || c.record.topics.includes("nbp-reference");
    let observation = "";
    if (rateSeries && checkedAt) {
      observation = `\nData sprawdzenia: ${checkedAt.toISOString().slice(0, 10)}. Wydawca: ${c.record.publisher}. Okres danych w tabeli: ${c.record.period}. Pobrano: ${c.record.fetchedAt.slice(0, 10)}.`;
    }
    parts.push(fence(`POZYCJA_${ref}`, body + heading + observation).text);
  }
  return parts.join("\n");
}

export async function runVerifier(
  verifier: LlmProvider,
  candidates: VerifierCandidate[],
  signal?: AbortSignal,
  checkedAt?: Date,
): Promise<{ votes: Map<VerifierCandidate, Exclude<VerifierVote, "brak">>; usage: ModelUsage }> {
  const items = candidates.slice(0, MAX_VERIFIER_ITEMS).map((c, i) => ({ ref: `V${i + 1}`, c }));
  const res = await verifier.complete({
    purpose: "verifier",
    system: VERIFIER_SYSTEM,
    user: buildVerifierPrompt(items, checkedAt),
    schema: VerifierOut,
    schemaName: "verifier_votes",
    tier: "fast",
    signal,
  });
  const byRef = new Map(res.data.votes.map((v) => [v.ref.trim(), v.vote]));
  const votes = new Map<VerifierCandidate, Exclude<VerifierVote, "brak">>();
  for (const { ref, c } of items) votes.set(c, byRef.get(ref) ?? "niepewne");
  return { votes, usage: res.usage };
}

/** Applies a vote to an assessment (pure). */
export function applyVote(a: EvidenceAssessment, vote: Exclude<VerifierVote, "brak">): EvidenceAssessment {
  if (vote === "sprzeciw") return { ...a, verifier: "sprzeciw", excluded: a.excluded ?? "verifier_dissent" };
  return { ...a, verifier: vote };
}
