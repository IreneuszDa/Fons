import type { Claim, CorpusRecord, CorpusStore, EvidenceAssessment, VerdictReport } from "../shared/contracts";
import { EU_COUNTRIES_URL } from "../corpus/ingest/eu-membership";
import { NATO_MEMBERS_URL, NATO_PL } from "../corpus/ingest/nato-data";
import { MONTHS_GENITIVE_PL } from "../security/dates";
import { answerEvidenceItem } from "./answer";
import { buildSummaryPl } from "./justify";
import { decideVerdict, detectInjection } from "./ports";
import { countryIdentity } from "./retrieval/subject";
import type { PublicationRun } from "./verify";

const events = {
  euro: { action: /^(?:(?:wprowadziły|przyjęły) euro|(?:przystąpiły|dołączyły|weszły) do strefy euro)$/iu,
    field: /^Strefa euro: w strefie euro od /u, label: "wprowadzenia euro" },
  schengen: { action: /^(?:przystąpiły|dołączyły|weszły) do strefy Schengen$/iu,
    field: /^Strefa Schengen: w strefie Schengen od /u, label: "przystąpienia do strefy Schengen" },
  eu: { action: /^(?:przystąpiły|dołączyły|weszły|wstąpiły) do (?:UE|Unii Europejskiej)$/iu,
    field: /^(?:W UE|Państwo członkowskie UE): od /u, label: "przystąpienia do UE" },
  nato: { action: /^(?:przystąpiły|dołączyły|weszły|wstąpiły) do NATO$/iu, label: "przystąpienia do NATO" },
};

type Event = keyof typeof events;

interface Comparison {
  countries: [string, string];
  event: Event;
  sameYear: boolean;
  inputMode: "question_yesno" | "claim";
  claim: Claim;
}

export function accessionComparison(text: string): Comparison | undefined {
  const input = text.trim().normalize("NFC");
  if (input.length > 180) return;
  const statement = input.replace(/^Czy\s+/iu, "").replace(/[.?]$/u, "").trim();
  // Keep the entire predicate in scope. Additional conditions on a country or date go through normal retrieval.
  const normalizedOrder = statement.replace(/ w (tym samym roku|różnych latach) ((?:wprowadziły|przyjęły|przystąpiły|weszły|wstąpiły|dołączyły) .+)$/iu, " $2 w $1");
  const match = /^(.+?) (?:i|oraz) (.+?) (.+?) w (tym samym roku|różnych latach)$/iu.exec(normalizedOrder);
  if (!match) return;
  const left = countryIdentity(match[1]!);
  const right = countryIdentity(match[2]!);
  const event = (Object.keys(events) as Event[]).find(key => events[key].action.test(match[3]!));
  if (!left || !right || left === right || !event) return;
  return { countries: [left, right], event, sameYear: match[4]!.toLowerCase() === "tym samym roku",
    inputMode: /^czy\s/iu.test(input) || input.endsWith("?") ? "question_yesno" : "claim",
    claim: { id: "c1", text: statement + ".", type: "fakt", temporal: { kind: "jednorazowe" },
      assertedAspect: "sedno", isMain: true, inputOverlap: 1 } };
}

type Entry = { record: CorpusRecord; name: string; quote: string; year: number };

function profileEntry(record: CorpusRecord, country: string, event: Exclude<Event, "nato">, now: number): Entry | undefined {
  const name = /^Unia Europejska: (.+?) — informacje o kraju UE$/u.exec(record.title)?.[1];
  if (record.sourceId !== "eu-portal" || !record.topics.includes("profil-panstwa") || !name || countryIdentity(name) !== country) return;
  const lines = record.text.split("\n").filter(line => events[event].field.test(line));
  if (lines.length !== 1) return;
  const quote = lines[0]!;
  const date = /^(\d{1,2}) (\p{L}+) (\d{4}) r\.$/u.exec(quote.replace(events[event].field, ""));
  if (!date) return;
  const month = MONTHS_GENITIVE_PL.findIndex(name => name === date[2]);
  const year = Number(date[3]);
  const when = new Date(Date.UTC(year, month, Number(date[1])));
  if (month < 0 || when.getUTCDate() !== Number(date[1]) || when.getTime() > now) return;
  return { record, name, quote, year };
}

function natoEntry(record: CorpusRecord, country: string, now: number): Entry | undefined {
  if (record.sourceId !== "nato" || !record.topics.includes("generated-from-data") || !record.topics.includes("data-przystapienia")) return;
  const row = /Lista państw członkowskich NATO: „([^”\n]+) ((?:19|20)\d{2})”\./u.exec(record.text);
  if (!row || countryIdentity(row[1]!) !== country) return;
  const name = NATO_PL[row[1]!];
  if (!name || record.title !== `NATO: ${name} — członkostwo w NATO od ${row[2]} r.` ||
      !record.text.startsWith(name + " — członkostwo w NATO od ") || !record.period?.startsWith(row[2]!) ||
      record.text.includes("państwo założycielskie") || !(Date.parse(record.period) <= now)) return;
  return { record, name, quote: row[0], year: Number(row[2]) };
}

export function accessionEntry(store: CorpusStore, country: string, event: Event, now: number): Entry | undefined {
  const slug = country.toLowerCase().replaceAll(" ", "-");
  const url = event === "nato" ? NATO_MEMBERS_URL : EU_COUNTRIES_URL.replace(/_pl$/u, "/" + slug + "_pl");
  const matches = (store.catalogPage?.(url) ?? []).flatMap(record => {
    if (record.url !== url || record.type !== "pierwotne" || record.level !== 1 || record.role !== "tresc" ||
        record.origin !== "corpus" || !(Date.parse(record.fetchedAt) <= now) ||
        detectInjection([record.title, record.text].join("\n"), "evidence", record.id).length) return [];
    return (event === "nato" ? natoEntry(record, country, now) : profileEntry(record, country, event, now)) ?? [];
  });
  return matches.length && matches.every(row => row.year === matches[0]!.year) ? matches[0] : undefined;
}

export function accessionComparisonReport(run: PublicationRun & { assessedRecords: Set<string> }, q: Comparison): VerdictReport | undefined {
  const now = run.deps.now();
  let left: Entry | undefined, right: Entry | undefined;
  try {
    left = accessionEntry(run.deps.store, q.countries[0], q.event, +now);
    right = accessionEntry(run.deps.store, q.countries[1], q.event, +now);
  } catch {
    run.recordLookup("official_accession_years", "unavailable", []);
    return;
  }
  if (!left || !right || left.record.id === right.record.id) return;
  const entries = [left, right];
  const equal = left.year === right.year;
  const relation = equal === q.sameYear ? "WSPIERA" : "OBALA";
  const records = new Map(entries.map(entry => [entry.record.id, entry.record]));
  const assessments: EvidenceAssessment[] = entries.map(({ record, quote, year }) => ({
    claimId: q.claim.id, recordId: record.id, aspect: "sedno", relation, quote, period: String(year),
    quoteVerified: true, quoteMatchScore: 1, verifier: "brak", decisive: true,
  }));
  const decision = decideVerdict({ claim: q.claim, records, assessments, now, singleKeyVerifier: false });
  if (decision.verdict !== (relation === "WSPIERA" ? "POTWIERDZONE" : "FALSZYWE")) return;
  run.stage("searching"); run.claims = [q.claim]; run.inputMode = q.inputMode;
  const ids = entries.map(e => e.record.id);
  run.recordLookup("official_accession_years", "completed", ids);
  ids.forEach(id => run.assessedRecords.add(id));
  const fact = `Wykaz podaje ${equal ? "ten sam rok" : "różne lata"} ${events[q.event].label} dla obu państw. ${left.name} (${left.year}), ${right.name} (${right.year}).`;
  const evidence = entries.map(({ record, quote }) => ({ ...answerEvidenceItem(record, quote, relation), usedForVerdict: true }));
  const verdict = { claimId: q.claim.id, verdict: decision.verdict, ruleApplied: decision.ruleApplied, strength: decision.strength,
    reasonPl: fact, registerFactPl: fact, evidence };
  return run.report({ status: "OK", verdictMode: "rules", mainVerdict: decision.verdict, verdicts: [verdict],
    summaryPl: buildSummaryPl(verdict, 0), transparencyPl: "Kod odczytał rok zdarzenia osobno z wpisu każdego państwa w tym samym rejestrze i porównał oba lata." });
}
