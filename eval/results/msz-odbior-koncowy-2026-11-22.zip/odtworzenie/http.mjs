import path from 'node:path';
import {randomBytes} from 'node:crypto';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
const [appArg, casesArg, outArg, mediaArg, mode]=process.argv.slice(2);
const media=mediaArg && path.resolve(mediaArg);
if(!outArg) throw Error('node --import tsx www.mjs <katalog-Fons> <wejścia.json> <nowy-katalog>');
const app=path.resolve(appArg), rows=JSON.parse(readFileSync(casesArg,'utf8')), out=path.resolve(outArg);
mkdirSync(out,{recursive:true});process.chdir(app);
const {serve}=await import(app+'/node_modules/@hono/node-server/dist/index.mjs');
const {loadConfig}=await import(app+'/src/server/config.ts');
const {buildProductionContext,openServerDatabase}=await import(app+'/src/server/wiring.ts');
const {createApp}=await import(app+'/src/server/app.ts');
const bridgeSecret=randomBytes(32).toString("hex");
const cfg=loadConfig({env:'production',dbPath:out+'/pomiar.db',usersPath:out+'/uzytkownicy.json',publicBaseUrl:'http://localhost',userIdPepper:randomBytes(32).toString('hex'),adminPassword:randomBytes(32).toString('hex'),adminPasswordGenerated:false,alertWebhookUrl:undefined,chatloomWebhookSecret:bridgeSecret,...(mode==='noindex'?{factCheckApiKey:undefined}:{}),...(mode==='noocr'?{openaiApiKey:undefined,mistralApiKey:undefined,anthropicApiKey:undefined}:{})});
const db=openServerDatabase(cfg), ctx=buildProductionContext(cfg,db);
const endpoint=createApp(ctx);
let server;
const port=await new Promise(resolve=>{server=serve({fetch:endpoint.fetch,hostname:'127.0.0.1',port:0},addr=>resolve(addr.port));});
const base='http://127.0.0.1:'+port;
function strip(key,value){if(['sessionId','token','senderId','csrf'].includes(key))return;return typeof value==='string'?value.replace(/\/(w|api\/report)\/[\w-]{12,}/g,'/$1/[ukryto]'):value;}
let cursor=0;
async function worker(){while(cursor<rows.length){
 const {id,q,image,recording}=rows[cursor++];const started=performance.now();
 try{
 const request={text:q};
 if(image){request.image={mime:image.endsWith(".png")?"image/png":"image/jpeg",base64:readFileSync(path.join(media,image)).toString("base64")}; if(image.endsWith(".jpg"))request.imageOptions={searchWeb:true};}
 if(recording)request.recording={mime:"audio/mpeg",base64:readFileSync(path.join(media,recording)).toString("base64")};const t=performance.now(),receivedAt=new Date().toISOString();
 const response=await fetch(base+'/api/chat'+(recording?'/recording':''),{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(request),signal:AbortSignal.timeout(210000)});
 const body=await response.json(), ms=Math.round(performance.now()-t),r=body.reply?.report;
 const back=r?.token?await fetch(base+'/api/report/'+r.token):undefined;
 const saved=back?.ok?await back.json():undefined;
 const result={id,q,receivedAt,http:response.status,ms,reply:body.reply,readback:back?.status,match:saved?((saved.report??saved).id===r.id):undefined};
 if(id==="G" && r){
  const {createDemoBridge}=await import(app+"/integrations/chatloom/demo.ts");
  const message=await createDemoBridge(async req=>fetch(base+new URL(req.url).pathname,{method:req.method,headers:req.headers,body:await req.arrayBuffer()}),bridgeSecret)(q);
  const url=message.match(/\/w\/([A-Za-z0-9_-]+)/)?.[1];
  if(!url) throw Error("Brak wyniku adaptera");
  const reread=await fetch(base+"/api/report/"+url);
  const body=await reread.json();const sms=body.report??body;
  result.secondChannel={message,report:sms,http:reread.status,sameVerdict:r.mainVerdict===sms.mainVerdict,sameSources:JSON.stringify(r.verdicts.flatMap(v=>v.evidence.map(e=>e.url)))===JSON.stringify(sms.verdicts.flatMap(v=>v.evidence.map(e=>e.url)))};
 }
 writeFileSync(out+'/'+id+'.json',JSON.stringify(result,strip,2));console.log(id,response.status,ms,body.reply?.kind,r?.mainVerdict,r?.cacheHit,back?.status,result.match);
 }catch(error){const failure={id,q,ms:Math.round(performance.now()-started),error:error instanceof Error?error.message:String(error)};writeFileSync(out+'/'+id+'.json',JSON.stringify(failure,strip,2));console.error(id,failure.error);}
}}
try{await Promise.all([worker(),worker()]);}finally{await new Promise(resolve=>server.close(resolve));db.close();}
