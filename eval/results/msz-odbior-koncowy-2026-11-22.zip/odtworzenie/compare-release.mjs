import {build} from 'esbuild';
import {createHash} from 'node:crypto';
import {readFileSync,readdirSync,writeFileSync} from 'node:fs';
import path from 'node:path';
const dir=path.resolve('.cache/msz-kontynuacja'), a=dir+'/wydanie-next',b=dir+'/wydanie-czat';
const sha=buf=>createHash('sha256').update(buf).digest('hex');
async function graph(root){
 const {metafile}=await build({entryPoints:['eval/real-text.mjs'],bundle:true,packages:'external',platform:'node',format:'esm',absWorkingDir:root,metafile:true,write:false,logLevel:'silent'});
 const inputs={};for(const file of Object.keys(metafile.inputs).sort())inputs[file]=sha(readFileSync(root+'/'+file));
 return inputs;
}
const [g1,g2]=await Promise.all([graph(a),graph(b)]);
const files=root=>readdirSync(root+'/src',{recursive:true,withFileTypes:true}).filter(e=>e.isFile()).map(e=>path.relative(root,path.join(e.parentPath,e.name))).sort();
const different=files(a).filter(f=>sha(readFileSync(a+'/'+f))!==sha(readFileSync(b+'/'+f)));
const engineDiffs=Object.keys({...g1,...g2}).filter(k=>g1[k]!==g2[k]);
const report={porownanePlikiSrc:files(a).length,rozniceSrc:different,liczbaPlikowWGrafiePomiaru:Object.keys(g1).length,zmienionePlikiWGrafiePomiaru:engineDiffs,skrotGrafu:sha(JSON.stringify(g1)),drugiSkrotGrafu:sha(JSON.stringify(g2)),modelPrezentacjiPozaGrafem:!Object.keys(g2).includes('src/shared/citizen-answer.ts')};
writeFileSync(dir+'/spojnosc-kodu.json',JSON.stringify(report,null,2));console.log(report);
if(different.length!==1||different[0]!=='src/shared/citizen-answer.ts'||files(a).length!==files(b).length||engineDiffs.length)process.exitCode=1;
