import path from 'node:path';
import {mkdirSync,writeFileSync} from 'node:fs';
import {createHash,randomBytes} from 'node:crypto';
const [app,out]=process.argv.slice(2).map(p=>path.resolve(p));mkdirSync(out,{recursive:true});process.chdir(app);
const {serve}=await import(app+'/node_modules/@hono/node-server/dist/index.mjs');
const {loadConfig}=await import(app+'/src/server/config.ts');
const {buildProductionContext,openServerDatabase}=await import(app+'/src/server/wiring.ts');
const {createApp}=await import(app+'/src/server/app.ts');
const password=randomBytes(32).toString('hex');
const cfg=loadConfig({env:'production',dbPath:out+'/ops.db',usersPath:out+'/users.json',userIdPepper:randomBytes(32).toString('hex'),adminPassword:password,adminPasswordGenerated:false,publicBaseUrl:'http://localhost',alertWebhookUrl:undefined});
const db=openServerDatabase(cfg),api=createApp(buildProductionContext(cfg,db));let server;
const port=await new Promise(resolve=>{server=serve({fetch:api.fetch,hostname:'127.0.0.1',port:0},address=>resolve(address.port));});
const base='http://127.0.0.1:'+port;
const req=(method,route,body,cookie)=>fetch(base+route,{method,headers:{'Content-Type':'application/json',...(cookie&&{cookie})},...(body&&{body:JSON.stringify(body)})});
const cookie=r=>r.headers.getSetCookie().map(c=>c.split(';')[0]).join(';');
const expect=(condition,label)=>{if(!condition)throw Error(label);};
const digest=s=>createHash('sha256').update(s).digest('hex');
const result={start:new Date().toISOString(),archive:[]};
try{
 const home=await req('GET','/api/archives');const user=cookie(home);
 const first=(await home.json()).items;expect(first.length===0 && !!user,"Brak świeżej sesji");
 const chat=await req('POST','/api/chat',{text:'Ilu posłów zasiada w Sejmie Rzeczypospolitej Polskiej?'},user);
 const report=(await chat.json()).reply.report;expect(chat.ok && !!report.token,"Brak rzeczywistego raportu użytkownika");
 for(const source of ['eurostat','gus-bdl']){
  const {url}=db.prepare("select url from records where source_id=? and origin='corpus' and role='tresc' and length(text)<=300 and topics_json like '%generated-from-data%' order by id limit 1").get(source);
  const preview=await req('POST','/api/archives/preview',{url},user);const {items}=await preview.json();const {sha256,...original}=items[0];
  const bodies=db.prepare('select text from records where id=?').get(original.recordId);
  const saved=await req('POST','/api/archives',{url,recordId:original.recordId,sha256},user);const {item}=await saved.json();
  const days=(Date.parse(item.expiresAt)-Date.parse(item.savedAt))/86400000;
  const verified=sha256===digest(JSON.stringify(original)) && bodies.text===item.excerpt;
  result.archive.push({source,recordId:item.recordId,url,http:preview.status,zapis:saved.status,sha256,identycznyFragment:verified,dniRetencji:days});
  expect(preview.ok&&saved.ok&&verified&&days===7,"Niezgodny zapis lub okres archiwizacji");
 }
 result.poOdswiezeniu=(await(await req('GET','/api/archives',null,user)).json()).items.length;
 const login=await req('POST','/api/admin/login',{username:'admin',password});const admin=cookie(login);expect(login.ok && !!admin,'Brak rzeczywistego zalogowania lokalnego');
 for(const kind of ['export.json?dataset=runs','export.csv?dataset=runs','export.json?dataset=stix']){
  const r=await req('GET','/api/admin/'+kind,null,admin);const body=await r.text();expect(r.ok,'Brak eksportu '+kind);
  if(kind.includes('stix')){const b=JSON.parse(body);const types=Object.fromEntries([...new Set(b.objects.map(o=>o.type))].map(t=>[t,b.objects.filter(o=>o.type===t).length]));result.stix={http:r.status,format:b.type,types};expect(b.type==='bundle' && b.objects.length>0,'Brak danych STIX');}
  else if(kind.includes('csv')){result.csv={http:r.status,bytes:Buffer.byteLength(body),zawieraPrzebieg:body.split(/\r?\n/g).filter(Boolean).length>1};expect(result.csv.zawieraPrzebieg,'Pusty CSV');}
  else{const ids=JSON.parse(body).runs;result.json={http:r.status,liczbaPrzebiegow:ids.length};expect(ids.length>0,'Pusty JSON');}
 }
 const before=await req('GET','/api/report/'+report.token);const erasure=await req('DELETE','/api/session',null,user);const counts=(await erasure.json()).deleted;
 const after=await req('GET','/api/report/'+report.token);result.usuniecieWlasnejProby={przed:before.status,usuniecie:erasure.status,po:after.status,archiwa:counts.archives,raporty:counts.reports};
 expect(before.ok && erasure.ok && after.status===404 && counts.archives===2 && counts.reports===1,'Niezgodna retencja sesji');
 result.complete=true;
} catch(error){result.error=error.message;process.exitCode=1;}
finally{result.koniec=new Date().toISOString();writeFileSync(out+'/operacje.json',JSON.stringify(result,null,2));await new Promise(resolve=>server.close(resolve));db.close();console.log(JSON.stringify(result));}
