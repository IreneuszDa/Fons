import path from 'node:path';
import {readFileSync,writeFileSync} from 'node:fs';
const dir=path.resolve('.cache/msz-kontynuacja');
const old=await import(dir+'/wydanie-next/src/shared/citizen-answer.ts'),now=await import(dir+'/wydanie-czat/src/shared/citizen-answer.ts');
const load=p=>JSON.parse(readFileSync(dir+'/'+p,'utf8'));
const series=load('seria-final/live100.json');if(!series.meta.complete)throw Error('Próba jeszcze trwa');
const reports=series.rows.map(r=>({id:r.case.id,r:r.report})).filter(item=>item.r);
const multi=load('docx-final/Multi.json').reply.report;
const before=old.citizenAnswerPl(multi),after=now.citizenAnswerPl(multi);
const replay=reports.map(({id,r})=>({id,before:old.citizenAnswerPl(r),after:now.citizenAnswerPl(r)}));
if(!after.includes('Szwecja')||!after.includes('Finlandia')||!after.includes('nie wiem')||!after.includes('— nie.'))throw Error('W krótkiej odpowiedzi brakuje części lub kierunku.');
const result={liczbaRaportow:reports.length,zmienione:replay.filter(e=>e.before!==e.after),stalyRaportMulti:{pierwotnie:before,poPoprawce:after,dowod:muliEvidence(multi)},bezNowegoWywolaniaModelu:true};
function muliEvidence(r){return r.verdicts.map(v=>({claimId:v.claimId,parts:v.parts}));}
writeFileSync(dir+'/powtorzenie-prezentacji.json',JSON.stringify(result,null,2));console.log(result.liczbaRaportow,result.zmienione.length,result.stalyRaportMulti.poPoprawce);
