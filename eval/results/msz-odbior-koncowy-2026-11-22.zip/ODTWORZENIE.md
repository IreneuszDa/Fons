# Jak odtworzyć pomiar Fonsa

Katalog `fons/` zawiera kod i dane wydania odpowiadającego ostatniej pełnej serii. W `dowody/wydanie/live100.json` są wejścia, oryginalny klucz, odpowiedzi, fragmenty źródeł, identyfikatory kodu i korpusu, czasy i koszty. Analogiczne dane wcześniejszej serii znajdują się w `dowody/v31/`. Pakiet zawiera manifest sum plików SHA-256. Po rozpakowaniu na macOS lub Linux można wykonać `shasum -a 256 -c SHA256SUMS.txt`.

## Uruchomienie

1. Przejdź do `fons/`, zainstaluj Node w wersji obsługiwanej przez projekt i wykonaj `npm ci`. Konfigurację usług, koszty oraz zależności systemowe opisuje README. W tym pomiarze użyto Node 22.15.0.
2. Skopiuj `.env.example` do `.env` i uzupełnij używane klucze zgodnie z README. Rzeczywiste wywołania API są rozliczane u dostawców. Model E5 wymaga wag dostępnych lokalnie albo pobrania przy pierwszym starcie.
3. W katalogu `fons/` uruchom `node --import tsx eval/real-text.mjs ../moj-pomiar`. Katalog wyników powinien być pusty. Można wznowić przerwaną serię przy tym samym kodzie, danych, konfiguracji i manifeście pytań. Raport bieżący zapisuje się po każdej odpowiedzi. W metadanych sprawdź `complete`, wersję, stan E5 oraz oba skróty SHA-256.
4. Aby policzyć także wynik łączny, wykonaj `node --import tsx ../odtworzenie/summary.mjs . ../moj-pomiar`. W dniu pomiaru klucz miał 100 unikalnych tekstów i 89 pozycji z etykietami klasyfikacji. Każde sprawdzenie dostaje tekst użytkownika i czas jego przyjęcia. Etykietę porównuje się dopiero z odpowiedzią silnika.
5. Uruchom `npm run typecheck`, `RUN_E5_TESTS=1 npm test -- --maxWorkers=2`, `npm run build` i `npx astryx doctor --built web-dist --json`. Audyt pochodzenia `npm run corpus:verify` odczytuje też lokalne kopie pobrane przez importer. Aby odtworzyć te kopie z sieci, uruchom według README import w osobnym katalogu roboczym. Zmiana treści u wydawcy może zmienić późniejszy wynik. W archiwum są dzienniki kontroli przeprowadzonej na zachowanych kopiach z dnia pomiaru.

## Przejście przez WWW

Node rozwiązuje moduły względem pliku skryptu. Skopiuj pliki MJS z `odtworzenie/` do wybranego podkatalogu wewnątrz `fons/`, np. do nowego `pomiar/`. W katalogu `fons/` wykonaj:

```sh
node --import dotenv/config --import tsx pomiar/http.mjs . ../dowody/docx.json ../moje-www ../wejscia
node --import dotenv/config --import tsx pomiar/http.mjs . ../dowody/noindex.json ../moje-bez-indeksu ../wejscia noindex
node --import dotenv/config --import tsx pomiar/http.mjs . ../dowody/noocr.json ../moje-bez-ocr ../wejscia noocr
node --import dotenv/config --import tsx pomiar/http.mjs . ../dowody/porownania.json ../moje-porownania
node --import dotenv/config --import tsx pomiar/http.mjs . ../dowody/nowe-pytania.json ../moje-nowe
WEB_SEARCH_DAILY_CAP=0 node --import dotenv/config --import tsx pomiar/http.mjs . ../dowody/limit-cases.json ../moj-limit
node --import dotenv/config --import tsx pomiar/operacje.mjs . ../moje-operacje
```

Skrypty potrzebują dostępu do sieci oraz możliwości otwarcia portu na 127.0.0.1. Używają odrębnej bazy w podanym katalogu wyników. Podaj nowy katalog dla każdego uruchomienia. Drugi kanał G korzysta z lokalnego podpisanego webhooka adaptera. Przypadki J uruchamiają prawdziwy serwer bez odpowiedniego dostawcy. Publikacji do operatora komórkowego, OpenCTI ani usługi alarmowania nie uruchamia się w tych krokach.

Własny koszt zależy od modelu, stawek, aktualnych źródeł i dostępności zewnętrznego wyszukiwania. Powtórzenie daje nowy pomiar. `odtworzenie/v31/` zawiera różniące się wcześniejsze pliki do nadpisania w osobnej kopii `fons/`. Plik `v31-odtworzenie.txt` wymienia pozycje, które pojawiły się dopiero w nowszym kodzie lub korpusie. Pierwsza seria miała osobny katalog bazy i kosztów. Recenzje znaczenia cytatów w tym pakiecie sporządził asystent AI.

## Zgodność wyświetlania i silnika

Po skończeniu zmian silnika dopracowano krótką odpowiedź na tezę mającą kilka części. Produkt w katalogu `fons/` uwzględnia tę poprawkę. Sprawdzenie grafu zależności pomiaru wykazało identyczną treść wszystkich 113 wykorzystywanych plików. W całym `src/` zmienił się jeden plik odpowiedzialny za prezentację. Wynik ponownego wygenerowania krótkich odpowiedzi ze 100 zapisanych raportów oraz dodatkowy rzeczywisty przebieg przez WWW dołączono do pakietu. Aby odtworzyć również identyczny SHA-256 całego `src/` zapisany w metadanych serii 100, nadpisz w osobnej kopii projektu plik `src/shared/citizen-answer.ts` plikiem o tej samej ścieżce z `odtworzenie/pomiar-100/`. Dla starszej serii zastosuj następnie nadpisania v31.
