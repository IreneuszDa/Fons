# Ostateczna ocena pierwszego i całego zestawu dowodów

**Pierwszy widoczny fragment uzasadnił werdykt w 7/10 spraw. Po przeczytaniu wszystkich widocznych fragmentów wynik również wynosi 7/10.** Silnik rozstrzygnął 8 spraw i wstrzymał ocenę w 2. Wśród spraw zakończonych rozstrzygnięciem z cytatem dowód był wystarczający w **7/8 (87,5%)**. Werdykt był zgodny z kluczem w **8/10 (80%)**.

Ocena obejmuje stałą, wcześniej wybraną próbę. Dla każdej głównej tezy przeczytano pierwszy niepusty cytat lub odczyt danych, jego wydawcę, tytuł i datę, a następnie pozostałe dowody widoczne w tej odpowiedzi. Wstrzymania pozostają w mianowniku 10. Przy pytaniu o lato zachowano wcześniejsze kryterium kalendarzowe. Do wyniku nie doliczono materiałów, które jedynie można znaleźć pod linkiem lub w innej weryfikacji. [Przebieg v32](wydanie/live100.json) · [Pomiar v31](ocena-cytatow.md) · [Wcześniejsza próba referencyjna](wczesniejsza-proba.md)

| ID | Sprawdzana teza | Werdykt | Zgodny z kluczem | Pierwszy dowód | Wszystkie razem |
|---|---|---|---|---|---|
| V2-A01 | Finlandia przystąpiła do NATO 4 kwietnia 2023 r. | Potwierdzone | Tak | Wystarcza | Wystarczają |
| V2-A02 | Polska przewodniczyła Radzie UE w pierwszej połowie 2025 r. | Brak dowodów | Nie | Wstrzymanie | Wstrzymanie |
| V2-A03 | Ukraina uzyskała status kandydata do UE latem 2022 r. | Potwierdzone | Tak | Nie wystarcza | Nie wystarczają |
| V2-A06 | Art. 5 Traktatu Północnoatlantyckiego zastosowano tylko raz, po zamachach z 11 września 2001 r. | Potwierdzone | Tak | Wystarcza | Wystarczają |
| V2-A07 | Bułgaria i Rumunia są w pełni w Schengen od 1 stycznia 2025 r. | Potwierdzone | Tak | Wystarcza | Wystarczają |
| V2-A08 | Polska jest członkiem UE od 1 maja 2004 r. | Potwierdzone | Tak | Wystarcza | Wystarczają |
| V2-A09 | Turcja nie jest członkiem UE. | Potwierdzone | Tak | Wystarcza | Wystarczają |
| V2-A10 | Ukraina jest członkiem NATO od 2024 r. | Brak dowodów | Nie | Wstrzymanie | Wstrzymanie |
| V2-A11 | Polska przyjęła euro w 2024 r. | Fałszywe | Tak | Wystarcza | Wystarczają |
| V2-A13 | Wybory prezydenckie w Polsce w 2025 r. wygrał Rafał Trzaskowski. | Fałszywe | Tak | Wystarcza | Wystarczają |

## Uzasadnienie według spraw

- **V2-A01.** Pierwszy odczyt z listy NATO wskazuje Finlandię i obie formy pełnej daty, 4 kwietnia 2023 r. i 2023-04-04. Drugi odczyt podaje tę samą datę i prowadzi do tej samej publikacji. [NATO](https://www.nato.int/en/about-us/organization/nato-member-countries)
- **V2-A02.** Klucz oczekuje potwierdzenia. Z 95 kandydatów silnik odczytał 8 fragmentów i wstrzymał ocenę. W odpowiedzi brakuje publikacji dokumentującej polską prezydencję i jej okres.
- **V2-A03.** Jedyny odczyt rozróżnia złożenie wniosku w lutym 2022 r. i uzyskanie statusu w czerwcu 2022 r. Brak dnia nadania statusu. Przy definicji kalendarzowej część czerwca przypada przed latem. Przy definicji meteorologicznej ten sam materiał wystarczałby do potwierdzenia. [Portal UE](https://european-union.europa.eu/principles-countries-history/eu-enlargement_pl)
- **V2-A06.** Pierwszy cytat NATO łączy konkretne zamachy z 2001 r. z pierwszym i jedynym użyciem art. 5. Trzy kolejne fragmenty tej samej publikacji podają te elementy również osobno. [NATO o obronie zbiorowej](https://www.nato.int/en/what-we-do/introduction-to-nato/collective-defence-and-article-5)
- **V2-A07.** Pierwszy komunikat Komisji z 3 stycznia 2025 r. wymienia oba kraje, 1 stycznia i objęcie pełnym członkostwem po zniesieniu kontroli lądowych. Tytuł i data publikacji ustalają rok. Drugi materiał podaje całą datę w jednym zdaniu. Późniejsze pozycje w raporcie zawierają dane o wcześniejszym etapie z 2024 r. [Pierwszy komunikat Komisji](https://home-affairs.ec.europa.eu/news/bulgaria-and-romania-join-schengen-area-2025-01-03_en) · [Drugi materiał Komisji](https://home-affairs.ec.europa.eu/policies/schengen/schengen-area_en)
- **V2-A08.** Jedyny fragment z oficjalnego profilu Polski brzmi „W UE: od 1 maja 2004 r.”. Nazwa państwa w tytule oraz data w cytowanym polu wystarczają do potwierdzenia. To przypadek poprawiony po v31, w którym czytelnik widział tylko rok. [Profil Polski](https://european-union.europa.eu/principles-countries-history/eu-countries/poland_pl)
- **V2-A09.** Pierwszy i jedyny odczyt oficjalnego wykazu określa Turcję jako kraj kandydujący do UE. Te dwie kategorie członkostwa wzajemnie się wykluczają. [Portal UE](https://european-union.europa.eu/principles-countries-history/eu-enlargement_pl)
- **V2-A10.** Klucz oczekuje odrzucenia tezy. W tym przebiegu silnik przeszukał 108 kandydatów, odczytał 8 fragmentów i wstrzymał ocenę. Raport nie pokazuje dowodu o statusie Ukrainy.
- **V2-A11.** Pierwsza publikacja UE z 12 stycznia 2026 r. wymienia Polskę wśród krajów, które jeszcze nie wprowadziły euro. Wyklucza to przyjęcie waluty w 2024 r. Drugi materiał wymienia PLN i przygotowania do przyszłego przyjęcia euro. [Wykaz UE](https://european-union.europa.eu/institutions-law-budget/euro/countries-using-euro_pl) · [Profil Polski](https://european-union.europa.eu/principles-countries-history/eu-countries/poland_pl)
- **V2-A13.** W obwieszczeniu PKW z 2 czerwca 2025 r. podano, że na prezydenta wybrany został Karol Tadeusz Nawrocki. Tytuł identyfikuje wybory i ich końcowy wynik. Wyklucza to zwycięstwo Rafała Trzaskowskiego. [Obwieszczenie PKW](https://api.sejm.gov.pl/eli/acts/DU/2025/714/text/O/D20250714.pdf)

W porównaniu z v31 pierwszy i pełny zestaw dowodów poprawiły się z 6/10 do 7/10 dzięki A08. Liczba rozstrzygnięć pozostała taka sama. W starszym pomiarze było również 7/10, przy 9 rozstrzygnięciach. Ta stała dziesiątka służy do śledzenia jakości cytowań na tych samych sprawach.

Badana wersja to `engine-2026.11.22-32-registers-and-dates`. Serię rozpoczęto 22 listopada 2026 r. o 06:31:25 UTC. Migawka zawierała 3852 rekordy, identyfikator `98c4f29a544289072d7037ece970708a6424b3662f8ce9898dd1a9ff85e2d717`.
