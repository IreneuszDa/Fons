# Cztery wcześniej zarejestrowane pytania dodatkowe

**Silnik spełnił kryterium w 3/4 odpowiedzi.** Prawidłowo rozstrzygnął i udokumentował dwa porównania państw, a jedno nieokreślone zgłoszenie lokalne pozostawił bez rozstrzygnięcia. W pytaniu o niemiecką gotówkę znalazł wyłącznie datę przyjęcia euro. Cztery odpowiedzi przez WWW otrzymały HTTP 200. Ponowny odczyt każdego raportu zwrócił HTTP 200 i zgodny identyfikator. Oceniono treść pokazaną użytkownikowi według kryteriów zapisanych przed przebiegiem. [Zestaw i kryteria](dodatkowe-kontrole.json)

| ID | Odpowiedź i dowód | Ocena |
|---|---|---|
| L1 | Tak. Oficjalny profil Bułgarii podaje członkostwo w UE od 1 stycznia 2007 r. Profil Rumunii podaje tę samą datę. Oba odczyty mają podpisane kraje i osobne adresy. [Raport](dodatkowe-final/L1.json) · [Bułgaria](https://european-union.europa.eu/principles-countries-history/eu-countries/bulgaria_pl) · [Rumunia](https://european-union.europa.eu/principles-countries-history/eu-countries/romania_pl) | Zaliczone |
| L2 | Nie. Pokazane profile łączą Grecję z 1981 r., a Portugalię z 1986 r. Obie strony porównania są udokumentowane. [Raport](dodatkowe-final/L2.json) · [Grecja](https://european-union.europa.eu/principles-countries-history/eu-countries/greece_pl) · [Portugalia](https://european-union.europa.eu/principles-countries-history/eu-countries/portugal_pl) | Zaliczone |
| L3 | Silnik poprawnie odczytał z niemieckiego profilu UE rok wejścia do strefy euro, 1999. Napisał, że źródło nie podaje daty zastąpienia marki przez banknoty i monety euro. Wymagane rozróżnienie między początkiem rozliczeń a wprowadzeniem gotówki 1 stycznia 2002 r. pozostało bez pełnej odpowiedzi i cytatu. [Raport](dodatkowe-final/L3.json) · [Profil Niemiec](https://european-union.europa.eu/principles-countries-history/eu-countries/germany_pl) | Niezaliczone |
| L4 | Silnik wstrzymał ocenę i wskazał, że potrzebny jest komunikat właściwego urzędu o dostępności okienka w konkretnym dniu. Użytkownik podał jedynie „w pobliskim urzędzie”. Raport nie zawiera rozstrzygającego cytatu. Wstrzymanie spełnia przyjęte kryterium. [Raport](dodatkowe-final/L4.json) | Zaliczone |

Wśród trzech pytań wymagających merytorycznego rozstrzygnięcia pełną odpowiedź z dowodem uzyskano w **2/3**. Sprawa lokalna stanowiła odrębny sprawdzian abstencji (**1/1**). Wynik 3/4 nie jest szacunkiem dokładności całej usługi.
