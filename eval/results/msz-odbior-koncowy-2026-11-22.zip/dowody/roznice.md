# Porównanie dwóch pełnych przebiegów na tych samych 100 przypadkach

Wynik względem zapisanego wzorca spadł z **70/100 w v31 do 64/100 w v32**. Jedenaście przypadków przeszło z trafnych na nietrafne, pięć w przeciwnym kierunku. Dziewięć z jedenastu utraconych punktów dotyczy sytuacji, w których v32 wstrzymało ocenę. [Surowy przebieg v31](v31/live100.json) · [Surowy przebieg v32](wydanie/live100.json)

| Wynik w v31 | Trafny w v32 | Nietrafny w v32 | Razem |
|---|---:|---:|---:|
| Trafny | 59 | 11 | 70 |
| Nietrafny | 5 | 25 | 30 |
| Razem | 64 | 36 | 100 |

**Utracone punkty.** W dziewięciu przypadkach doszło do nadmiernej abstencji: A17, A18, A19, B04, R02, R03, LT03, V2-A12 i V2-P07. Pozostałe dwa to B05, gdzie „Wprowadzające w błąd” zmieniło się na „Fałszywe”, i V2-P03, gdzie nastąpiła zmiana odwrotna.

**Odzyskane punkty.** W X02, N05, V2-A15 i V2-P06 v32 podało właściwy werdykt po wcześniejszej abstencji. W V2-C03 wcześniejsze „Fałszywe” zmieniło się na oczekiwany „Brak dowodów”. W całej setce wszystkie abstencje wzrosły z 25 do 29, w tym abstencje przy oczekiwanym werdykcie merytorycznym z 21 do 24. Łącznie główna etykieta zmieniła się w 20 przypadkach, w tym w czterech, które w obu przebiegach otrzymały zero punktów.

## Co widać w przekazanych dowodach

| Przypadek | Wynik i ocena materiału |
|---|---|
| **LT03. Litwa, Łotwa i Estonia w NATO w 2004 r.** | W v32 raport twierdzi, że nie ma wystarczającego dowodu dla Łotwy. Ten sam raport zawiera osobny wiersz o jej członkostwie od 29 marca 2004 r. i zbiorczy wiersz NATO z tą datą oraz nazwami wszystkich trzech państw. Zbiorczy wiersz został nawet oznaczony jako użyty przy ocenie. To bezpośredni przykład abstencji mimo dostarczenia kompletnej podstawy użytkownikowi. |
| **B05. Zakaz importu rosyjskiej ropy rurociągami w 2022 r.** | Raport v32 zawiera fragment EUR-Lex o ogólnym zakazie importu i fragment o wyjątku dla dostaw rurociągiem. Wykorzystał drugi i wydał „Fałszywe”. Wzorzec premiuje „Wprowadzające w błąd”, aby zachować także kontekst ogólnego zakazu. Część dowodowa pozwala użytkownikowi poznać oba elementy. |
| **V2-P03. Czy Andrzej Duda nadal jest prezydentem?** | V32 pokazuje komunikat o objęciu urzędu przez Karola Nawrockiego 6 sierpnia 2025 r. i podpis prezydenta Andrzeja Dudy z 2020 r. Wniosek o nieaktualności jest uzasadniony tym materiałem. Wzorzec dla pytania ze słowem „nadal” wymaga etykiety „Fałszywe”, więc odpowiedź nie zalicza testu. |

Oba przebiegi mają identyczny skrót zestawu przypadków oraz te same nazwy modeli głównego i pomocniczego. Różnią się wersją kodu i migawką korpusu (3850 wobec 3852 rekordów). W obu aktywne było wyszukiwanie na żywo. Z pojedynczego uruchomienia każdej wersji można ustalić powyższe przejścia i wskazać treść dostarczonych cytatów. Ustalenie, ile zmian spowodował sam kod, zmienność wyników wyszukiwania lub decyzje modeli, wymagałoby kontrolowanego powtórzenia na tych samych wynikach wyszukiwania i odpowiedziach modeli.
