# Członkostwo w UE i NATO

W wydaniu v31 brak wpisu dla Białorusi powodował wstrzymanie odpowiedzi w X02 i N05. W roboczej wersji po naprawie serwer odpowiedział prawidłowo na obie tezy oraz cztery kontrole. Dla państwa spoza organizacji raport pokazuje pełny wykaz, liczbę państw podaną przez wydawcę, adres publikacji i datę odczytu. [Odpowiedzi WWW](abstencje/wykaz-www)

## Wykazy w pierwotnej migawce

| Organizacja | Co rzeczywiście zachowano | Co sprawdzał importer v31 |
|---|---|---|
| NATO | Strona NATO z 21 listopada zawiera deklarację 32 członków oraz odrębny alfabetyczny wykaz. Między nagłówkiem wykazu a początkiem historii rozszerzeń są 32 różne państwa. Wszystkie 32 znalazły się też w rekordach dla pojedynczych krajów. | Importer porównywał liczbę wierszy z wpisaną na stałe wartością 32 i zapisywał ostrzeżenie. Wiersze członkowskie powstawały według listy znanych rund rozszerzeń. Brakowało dowodu kompletności używanego przy rozstrzyganiu nieczłonkostwa. [Wykaz NATO](https://www.nato.int/en/about-us/organization/nato-member-countries) |
| UE | Pierwsza strona katalogu sygnalizowała 27 wyników oraz dalszą stronę. Stary parser zwracał 21 wystąpień, w tym Austrię dwukrotnie. Do korpusu trafiło 20 różnych pozycji katalogu. W odrębnym zbiorze znalazło się też 27 profili pobieranych według listy adresów z kodu. | Importer kończył odczyt na pierwszej stronie i zgłaszał ostrzeżenie. Sama suma profili pobranych ze zdefiniowanych wcześniej adresów nie wykryłaby zmiany składu organizacji. [Wykaz UE](https://european-union.europa.eu/principles-countries-history/eu-countries_pl) |

Druga kompletna enumeracja UE jest dostępna na stronie poświęconej euro. W jednym odczycie wydawca podaje 21 członków strefy euro spośród 27 państw Unii, wymienia wszystkie 21, następnie pięć państw oczekujących na przyjęcie euro oraz Danię korzystającą z wyłączenia. Razem jest 27 różnych, rozpoznanych państw. [Podział państw UE według waluty](https://european-union.europa.eu/institutions-law-budget/euro/countries-using-euro_pl)

## Zachowanie po zmianie

Importer NATO wymaga obu nagłówków ograniczających wykaz, wiersza kraju i roku dla każdej pozycji, liczby odczytanej z treści wydawcy i dokładnie tylu różnych państw. Importer UE przechodzi po odnośnikach „Następna”, sprawdza liczbę wyników, pozycje każdej strony, unikalność oraz wspólny czas odczytu. Przy próbie z 22 listopada serwis UE odpowiedział HTTP 429 dla drugiej strony. Pierwsza strona nie wystarczyła do potwierdzenia kompletności. Importer użył wówczas opublikowanego przez UE podziału 21 + 5 + 1 z jednego dokumentu. [Porównanie pierwotnego odczytu](abstencje/registers.json)

Wniosek o nieczłonkostwie wymaga rozpoznanej nazwy kraju i urzędowego wykazu odczytanego w ciągu ostatnich 30 dni. Silnik sprawdza tożsamości krajów, organizację, adres publikacji oraz deklarowaną liczbę także przy odczycie rekordu. Brak potwierdzonego wykazu pozostawia możliwość rozstrzygnięcia na podstawie jednoznacznego indywidualnego wpisu. W razie braku obu podstaw silnik wstrzymuje odpowiedź.

## Kontrola źródłowa i WWW

Polecenie `node --import tsx src/corpus/verify.ts --only membership-registers` potwierdziło 32/32 państwa NATO oraz 27/27 państw UE względem zapisanych dokumentów wydawców. W dwóch dodatkowych kontrolach audyt wykrył usunięcie wykazu i podmianę jednego państwa przy zachowaniu prawidłowej liczby wierszy. [Wyniki audytu](abstencje/wykazy-audyt.json)

| Próba WWW | Wynik |
|---|---|
| Białoruś należy do UE | Nie. [Raport X02](abstencje/wykaz-www/X02.json) |
| Białoruś nie jest członkiem NATO | Tak. [Raport N05](abstencje/wykaz-www/N05.json) |
| Norwegia jest członkiem UE | Nie. [Raport](abstencje/wykaz-www/norwegia.json) |
| Austria należy do NATO | Nie. [Raport](abstencje/wykaz-www/austria.json) |
| Polska należy do NATO | Tak. [Raport](abstencje/wykaz-www/polska.json) |
| Portugalia należy do UE | Tak. [Raport](abstencje/wykaz-www/portugalia.json) |

Wszystkie sześć odpowiedzi i sześć ponownych odczytów raportów zwróciło HTTP 200. W tej ścieżce silnik korzysta z rzeczywistego wykazu bez wywołania modelu. Zmiana dodała dwa rekordy do korpusu i zachowała treść wszystkich wcześniejszych rekordów. Seria sześciu pomiarów jest odrębna od zakończonej ewaluacji zamrożonego v31.
