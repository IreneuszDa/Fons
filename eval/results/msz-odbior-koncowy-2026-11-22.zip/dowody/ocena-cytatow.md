# Czy dowód pokazany użytkownikowi uzasadnia werdykt?

**W 6 z 10 spraw pierwszy fragment wystarczył do uzasadnienia rozstrzygnięcia.** Po przeczytaniu wszystkich fragmentów wynik nadal wynosił **6/10**. Silnik rozstrzygnął 8 spraw, a w 2 wstrzymał ocenę. Wśród 8 rozstrzygnięć z cytatem pierwszy fragment wystarczył w **6/8 (75%)**. Same werdykty zgodziły się z kluczem w **8/10 (80%)**.

Analiza z 22 listopada 2026 r. obejmuje te same 10 identyfikatorów i stosuje kryteria wcześniejszego pomiaru. Dla każdej głównej tezy odczytano pierwszy niepusty cytat lub odczyt danych, jego wydawcę, tytuł i datę, a następnie wszystkie dowody widoczne w tej samej odpowiedzi. Liczba dostępnych kandydatów i sama zgodność werdyktu z kluczem nie wpływają na ocenę treści dowodu. W mianowniku 10 pozostają oba wstrzymania. To próba celowa wybrana przed bieżącym pomiarem. [Poprzednia ocena](wczesniejsza-proba.md) · [Pełny przebieg](v31/live100.json)

| ID | Twierdzenie | Werdykt | Zgodny z kluczem | Pierwszy dowód wystarcza | Wszystkie dowody razem wystarczają |
|---|---|---|---|---|---|
| V2-A01 | Finlandia przystąpiła do NATO 4 kwietnia 2023 r. | Potwierdzone | Tak | Tak | Tak |
| V2-A02 | Polska sprawowała prezydencję w Radzie UE w pierwszej połowie 2025 r. | Brak dowodów | Nie | Wstrzymanie | Wstrzymanie |
| V2-A03 | Ukraina uzyskała status kandydata do UE latem 2022 r. | Potwierdzone | Tak | Nie | Nie |
| V2-A06 | Art. 5 Traktatu Północnoatlantyckiego zastosowano tylko raz, po zamachach z 11 września 2001 r. | Potwierdzone | Tak | Tak | Tak |
| V2-A07 | Od 1 stycznia 2025 r. Bułgaria i Rumunia są w pełni w strefie Schengen. | Potwierdzone | Tak | Tak | Tak |
| V2-A08 | Polska jest członkiem UE od 1 maja 2004 r. | Potwierdzone | Tak | Nie | Nie |
| V2-A09 | Turcja nie jest członkiem UE. | Potwierdzone | Tak | Tak | Tak |
| V2-A10 | Ukraina jest członkiem NATO od 2024 r. | Brak dowodów | Nie | Wstrzymanie | Wstrzymanie |
| V2-A11 | Polska przyjęła euro w 2024 r. | Fałszywe | Tak | Tak | Tak |
| V2-A13 | Wybory prezydenckie w Polsce w 2025 r. wygrał Rafał Trzaskowski. | Fałszywe | Tak | Tak | Tak |

## Uzasadnienie ocen

- **V2-A01.** Pierwszy odczyt NATO podaje państwo, dokładną datę złożenia dokumentu akcesyjnego i uzyskanie członkostwa. Drugi fragment pochodzi z tej samej strony. Dodatkowy tekst NATO i komunikat Komisji potwierdzają pełną datę. [Pierwszy materiał NATO](https://www.nato.int/en/about-us/organization/nato-member-countries) · [Rozszerzenie NATO](https://www.nato.int/en/what-we-do/partnerships-and-cooperation/enlargement-and-article-10) · [Komisja Europejska](https://commission.europa.eu/strategy-and-policy/state-union-addresses/state-union-2023/defending-european-peace_en)
- **V2-A02.** Klucz oczekuje potwierdzenia prezydencji w pierwszym półroczu. Silnik znalazł 98 kandydatów, przeczytał 8 fragmentów, a w odpowiedzi nie pokazał żadnego dowodu rozstrzygającego. Brak adresu źródła w raporcie.
- **V2-A03.** Jedyny odczyt wymienia Ukrainę i nadanie statusu w czerwcu 2022 r. Przy przyjętej wcześniej kalendarzowej definicji lata część czerwca przypada przed jego początkiem. Do potwierdzenia potrzebny jest dzień lub wskazanie części miesiąca. Przy meteorologicznej definicji lata ten sam fragment wystarcza. [Portal UE](https://european-union.europa.eu/principles-countries-history/eu-enlargement_pl)
- **V2-A06.** Pierwszy cytat NATO łączy użycie art. 5 po zamachach z 11 września 2001 r. ze stwierdzeniem, że był to jedyny taki przypadek. Dwa kolejne cytaty z tej samej publikacji dokumentują te elementy oddzielnie. [NATO o art. 5](https://www.nato.int/en/what-we-do/introduction-to-nato/collective-defence-and-article-5)
- **V2-A07.** Komisja podaje oba państwa, pełne członkostwo i zniesienie kontroli lądowych od 1 stycznia. Datę roczną identyfikują pierwszy materiał z 3 stycznia 2025 r. i następny cytat podający 1 stycznia 2025 r. Pozostałe trzy fragmenty o 2024 r. opisują wcześniejszy etap uczestnictwa w Schengen. [Pierwszy komunikat Komisji](https://home-affairs.ec.europa.eu/news/bulgaria-and-romania-join-schengen-area-2025-01-03_en) · [Komisja o strefie Schengen](https://home-affairs.ec.europa.eu/policies/schengen/schengen-area_en)
- **V2-A08.** Jedyny fragment wskazuje rok 2004. Czytelnik nie znajdzie w tym materiale daty 1 maja. Dzień podany przez użytkownika i powtórzony w treści sprawdzanej tezy nie może służyć za drugi dowód. [Portal UE](https://european-union.europa.eu/principles-countries-history/eu-countries_pl)
- **V2-A09.** Pierwszy i jedyny odczyt danych klasyfikuje Turcję jako kraj kandydujący do Unii. Aktualna klasyfikacja kandydata wyklucza równoczesne członkostwo. Zastosowano to samo kryterium co we wcześniejszym audycie. [Portal UE](https://european-union.europa.eu/principles-countries-history/eu-enlargement_pl)
- **V2-A10.** Klucz wskazuje fałsz. Bieżąca odpowiedź zawiera wstrzymanie. Spośród 104 kandydatów przeczytano 8 fragmentów i żadnego nie pokazano jako dowodu. Wcześniejszy pomiar miał potwierdzone obalenie z publikacji NATO, ale tamta publikacja nie występuje w bieżącej odpowiedzi. Brak adresu źródła w raporcie.
- **V2-A11.** Jedyny fragment profilu Polski wskazuje aktualną walutę PLN oraz przygotowania do przyjęcia euro. Te dwa pola wspólnie uzasadniają odrzucenie twierdzenia o wprowadzeniu euro w 2024 r. [Profil Polski w UE](https://european-union.europa.eu/principles-countries-history/eu-countries/poland_pl)
- **V2-A13.** Fragment urzędowego obwieszczenia PKW, opublikowanego 2 czerwca 2025 r., podaje nazwisko osoby wybranej na prezydenta RP. Wskazanie Karola Nawrockiego w ostatecznym wyniku wyklucza zwycięstwo Rafała Trzaskowskiego. [Obwieszczenie PKW](https://api.sejm.gov.pl/eli/acts/DU/2025/714/text/O/D20250714.pdf)

W poprzednim audycie pierwszy i pełny zestaw dowodów uzasadniały 7/10 rozstrzygnięć. Wśród rozstrzygnięć z cytatem było to 7/9. Spadek wyniku na całej stałej próbie z 7/10 do 6/10 wynika z wstrzymania w V2-A10. Powtórzyły się oba przypadki, w których źródło podaje czas mniej precyzyjnie niż teza.

Wersja silnika `engine-2026.11.22-31-comparable-evidence`, 3850 rekordów, migawka `f8f2b23e95f8ac1d32a1d924b2958f2f250caa170132400b88869adccceadaba`. Początek przebiegu 06:16:50 UTC. [Dane dziesięciu spraw w pełnym przebiegu](v31/live100.json)
