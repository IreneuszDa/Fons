# Materiały wymagane w sekcji 4 zadania MSZ

Kontrola plików lokalnych i odnośników pilotowej prezentacji, 22 listopada 2026 r.

| Wymaganie | Wynik |
|---|---|
| Nazwa zespołu, tytuł i opis do 4000 znaków | `docs/OPIS.md` ma 2471 znaków ze spacjami, łącznie ze znacznikami Markdown i odnośnikami. Zawiera tytuł i roboczą nazwę zespołu Fons. |
| PDF do 12 slajdów | `docs/konkurs/prezentacja.pdf` ma 7 stron o wymiarach 960 × 540 pt. Zawiera problem i użytkowników, architekturę, demonstrację, testy, ryzyka oraz proponowany pilotaż. |
| Film do 3 minut dostępny pod linkiem | `docs/konkurs/demo.mp4` trwa 42,080 s. Zawiera obraz 1280 × 800 H.264, ścieżkę AAC i polskie napisy. Czat sprawdza pytanie o bezpłatną komunikację, następnie pokazuje odpowiedź i źródło. Odnośniki względne działają w lokalnym komplecie. |
| Repozytorium i instrukcja uruchomienia | `docs/OPIS.md` wskazuje repozytorium, `README.md` podaje wymagania i polecenia startowe. GitHub API potwierdziło repozytorium prywatne i gałąź domyślną `main`. Dostęp konkretnych kont jury pozostaje niepotwierdzony. |
| Architektura, modele i dostawcy, źródła i licencje, ryzyka | `docs/OPIS.md`, `docs/METODA-WERYFIKACJI.md`, `docs/TECHNICAL.md` i `docs/SOURCES.md` pokrywają te zagadnienia. W OPIS wymieniono ograniczenia związane z cytatem, aktualnością, doborem wydawców, prywatnością, wstrzyknięciami instrukcji, dostępnością i nadużyciami. |
| Wyniki i dane do odtworzenia | `docs/konkurs/WYNIKI.md` wskazuje pomiary i archiwum `eval/results/msz-po-naprawie-2026-11-22.zip`. Slajd 5 po aktualizacji pokazuje wersję v32 (64/100), wskazuje wynik porównawczy v29 (72/100) i odsyła do nowego raportu KONTYNUACJA.md. Wyniki automatyczne nie zastępują niezależnej oceny eksperckiej lub testu jury. |

Uwierzytelnione odczytanie zawartości `docs/konkurs` na domyślnym `main` przez GitHub Contents API zwróciło 404. Lokalnie katalog był nieśledzony w Git. Samo nadanie dostępu do repozytorium nie udostępni brakujących plików. Link w obecnym zgłoszeniu musi prowadzić do miejsca, gdzie rzeczywiście znajdują się film, prezentacja i bieżące wyniki, dostępnego dla jury. Publikacji i nadawania dostępów nie wykonywano. Odrębna publiczna demonstracja aplikacji jest opcjonalna według sekcji 4. [Repozytorium wskazane w opisie](https://github.com/IreneuszDa/Fons)
