# Sprawdzenie przypadków wymagających porównania źródeł

22 listopada 2026 r. Oceniany zbiór zawiera siedem zgłoszeń z oczekiwaniem bloku sprzeczności. W historycznych przebiegach `.cache/msz-final/poprawki/live100.json` i `.cache/msz-v27-100/live100.json` blok pojawił się 0/7 razy. Poniżej dowody obecne w pierwszym przebiegu oraz komentarz do nowych materiałów w `data/corpus/research-estimates.jsonl`.

| Zgłoszenie | Kandydaci / przeczytane rekordy w historycznym przebiegu | Ustalenia z publikacji |
|---|---:|---|
| C01, granica polsko-białoruska w 2023 r. | 100 / 8 | Brak cytatu w starym raporcie. Pozyskany komunikat Straży Granicznej wprost mówi o ponad 26 tys. prób. Frontex publikuje odrębną statystykę dla wschodniego szlaku lądowego UE. |
| C02, liczebność rosyjskiej floty cieni | 90 / 8 | Brak cytatu w starym raporcie. KSE podał oszacowanie 435 statków w I kwartale 2024 r. według swojej definicji. Lista statków objętych sankcjami obejmuje wybrane jednostki. Do tezy o dniu zgłoszenia potrzebne jest aktualne oszacowanie całej floty. |
| C03, uchodźcy z Ukrainy w Polsce w 2023 r. | 105 / 8 | Trzy cytaty dotyczyły beneficjentów ochrony czasowej w konkretnych dniach. Nowy dokument UNHCR mówi o 956 633 osobach w opisanych kategoriach na koniec grudnia 2023 r. Pytanie nie wskazuje dnia ani sposobu liczenia osób w ciągu roku. |
| C04, poparcie dla członkostwa Polski w UE | 109 / 8 | Brak cytatu w starym raporcie. Nowy rekord CBOS zawiera 82% w styczniowym badaniu 2026 r. Do wykazania sprzeczności potrzebny jest drugi porównywalny pomiar. |
| V2-C01, obecna liczba uchodźców z Ukrainy w Polsce | 92 / 8 | Brak cytatu w starym raporcie. Zaktualizowany Eurostat podaje 858 545 beneficjentów ochrony czasowej we wrześniu 2026 r. Jego określenie populacji ogranicza wniosek. |
| V2-C02, wydatki Rosji w 2024 r. | 111 / 8 | Brak cytatu w starym raporcie. Wczesne oszacowania SIPRI (7,1%) i IISS (6,7%) przypadały po przeciwnych stronach progu 7%. Po rewizji SIPRI (6,87415%) oba są poniżej progu. |
| V2-C03, wydatki Polski na obronność w 2025 r. | 63 / 8 | Dwa cytaty pochodziły z tego samego raportu NATO i podawały szacunek 4,48% PKB. Zapowiedź MON 4,7% opisuje plan wydatków. Porównanie wykonania wymaga źródeł dla tego samego etapu i definicji. |

## Próby z rzeczywistym modelem i korpusem

- W aktualnym pytaniu V2-C02 źródła IISS i nowa seria SIPRI wskazały wartości poniżej 7%. Silnik zwrócił FAŁSZYWE. [Raport](V2-C02-2026-11-22T06-10-27.010Z.json)
- Według stanu publikacji na 30 kwietnia 2025 r. silnik znalazł SIPRI 7,1% i IISS 6,7%, sprawdził obie wypowiedzi i pokazał dwie strony sporu o próg. W dwóch kolejnych próbach uzyskano BRAK DOWODÓW, regułę 5. [Pierwszy przebieg](rosjaArchiwum-2026-11-22T06-10-27.148Z.json) · [Powtórzenie](rosjaArchiwum-2026-11-22T06-14-25.272Z.json)
- Przy frekwencji Marszu Niepodległości z 11 listopada 2026 r. organizator podał około miliona osób, a KRRiT przytoczyła szacunek policji wynoszący około 250 tys. Pierwszy przebieg zwrócił FAŁSZYWE mimo niepewnego odczytu całej wypowiedzi zestawiającej obie liczby. Po pierwszej poprawce silnik wstrzymał się. Po przekazaniu weryfikatorowi zapisanego okresu dokumentu i skróceniu cytatu do jednego przypisanego szacunku obie relacje otrzymały zgodę, a silnik pokazał blok sprzeczności. [Przed poprawką](marsz-2026-11-22T06-10-07.945Z.json) · [Wstrzymanie](marsz-2026-11-22T06-13-03.523Z.json) · [Dwie strony](marsz-2026-11-22T06-14-24.941Z.json)

Końcowe powtórzenie po usunięciu identycznych cytatów po tej samej stronie pokazało dokładnie jeden rekord organizatora i jeden rekord KRRiT. W osobnej weryfikacji C01 poprawka reguły 7 dała POTWIERDZONE na podstawie komunikatu Straży Granicznej. [Marsz](marsz-2026-11-22T06-16-18.608Z.json) · [Granica](C01-2026-11-22T06-16-18.809Z.json) · [289 testów regresji](regression-frozen.log)

Próby archiwalna i frekwencyjna są odrębnymi przypadkami kontrolnymi. Wynik oficjalnych siedmiu zgłoszeń pozostaje wynikiem niezmienionego klucza. Pliki JSON zawierają identyfikatory, modele, źródła, cytaty i głosy weryfikatora. Ograniczenie wynika z dostępności porównywalnych publikacji oraz zmienności kolejnych wywołań modelu.
