import {readFileSync,writeFileSync,renameSync,existsSync,appendFileSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {pathToFileURL,fileURLToPath} from 'node:url';
const dir=dirname(fileURLToPath(import.meta.url)),repo=process.cwd(),app=dir+'/app';process.chdir(app);
const at=rel=>pathToFileURL(resolve(rel)).href;
const {loadConfig}=await import(at('src/server/config.ts'));
const {openDatabase,ensureCorpusLoaded}=await import(at('src/corpus/store.ts'));
const {createEngineDeps,verifyInput,PIPELINE_VERSION}=await import(at('src/engine/verify.ts'));
const {warmUp}=await import(at('src/engine/retrieval/index.ts'));
const {runFromReport,errorRun,summarize,isRunCorrect}=await import(repo+'/eval/metrics.ts');
const file=dir+'/heldout.json',log=dir+'/heldout.log';
const say=s=>{console.log(s);appendFileSync(log,s+'\n')};
const raw=readFileSync(repo+'/eval/cases/heldout-v2.jsonl','utf8');
const selected=raw.split('\n').filter(Boolean).map(JSON.parse).filter(c=>/^V2-(A|B|C|X|P)\d{2}$/.test(c.id)&&c.input.kind==='text'&&!c.fault&&!c.checks?.fixture&&!c.expected.attack);
if(selected.length!==41) throw new Error('Unexpected case count');
const cfg=loadConfig({dbPath:dir+'/heldout.sqlite',liveSearch:true});
const db=openDatabase(cfg.dbPath);
const corpus=ensureCorpusLoaded(db);
const deps=createEngineDeps(db,cfg);
if(!deps.llm.available) throw new Error('No real provider configured');
const warm=await warmUp(deps.branches);
const recordText=id=>deps.store.get(id)?.text;
const prior=existsSync(file)?JSON.parse(readFileSync(file,'utf8')):null;
const started=prior?.meta.started??new Date().toISOString();
const hash=rel=>createHash('sha256').update(readFileSync(rel)).digest('hex');
const sha=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8',cwd:repo}).trim();
const meta={started,workers:1,selection:'All text A/B/C/X/P from heldout-v2 (41); excludes URL, D/H, E/J and fixtures or fault injection',caseFile:'eval/cases/heldout-v2.jsonl',caseHash:hash(repo+'/eval/cases/heldout-v2.jsonl'),gitSha:sha,verifySourceHash:hash('src/engine/verify.ts'),corpus,PIPELINE_VERSION,provider:deps.llm.name,main:cfg.modelMain,fast:cfg.modelFast,verifier:deps.verifier.name,singleKey:deps.singleKey,liveSearch:cfg.liveSearch,branches:deps.branches.map(b=>b.id),warm};
if(prior&&(meta.caseHash!==prior.meta.caseHash||meta.verifySourceHash!==prior.meta.verifySourceHash||meta.corpus.snapshotId!==prior.meta.corpus.snapshotId))throw new Error('Incompatible input or code snapshot');
say(JSON.stringify(meta));
const results=new Map((prior?.results??[]).map(x=>[x.case.id,x]));
function save(finished=false){
 const order=selected.map(c=>results.get(c.id)).filter(Boolean);
 const metrics=order.length?summarize(order.map(x=>({case:x.case,runs:[x.run]})),{recordText}):null;
 const out={meta:{...meta,...(finished?{finished:new Date().toISOString()}:{}),complete:finished},count:order.length,planned:selected.length,metrics,results:order};
 writeFileSync(file+'.writing',JSON.stringify(out,null,2));renameSync(file+'.writing',file);
}
save(false);
for(const c of selected){
 if(results.has(c.id)) continue;
 const info={id:c.id,split:c.split,scenario:c.scenario,inputKind:c.input.kind,expected:c.expected,tags:c.tags??[],inputPreview:c.input.text,checks:c.checks??{}};
 const from=new Date().toISOString();const t=performance.now();let report;let run;
 try{
 report=await verifyInput({channel:'eval',kind:'text',receivedAt:from,text:c.input.text},deps,{signal:AbortSignal.timeout(180000)});
 run=runFromReport(report,{run:1,latencyMs:performance.now()-t,recordText});
 }catch(e){run=errorRun(1,performance.now()-t,e.message)}
 results.set(c.id,{case:info,from,run,report,correct:isRunCorrect(info,run)});save();
 say([results.size,selected.length,c.id,run.status,run.mainVerdict,run.answer?'answer':'',run.costUsd,Math.round(run.latencyMs),run.warnings.join(',')].join(' '));
}
save(true);db.close();
