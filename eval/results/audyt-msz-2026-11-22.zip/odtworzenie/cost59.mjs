import {readFileSync,writeFileSync,renameSync,existsSync,appendFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {resolve,dirname} from 'node:path';
const dir=dirname(fileURLToPath(import.meta.url)),repo=process.cwd(),app=dir+'/app',output=dir+'/cost59.json';
const inputs=JSON.parse(readFileSync(dir+'/cost59-inputs.json','utf8'));
const hashFile=path=>createHash('sha256').update(readFileSync(path)).digest('hex');
if(inputs.length!==59||new Set(inputs.map(x=>x.sha256)).size!==59)throw Error('Invalid selection');
process.chdir(app);
const load=path=>import(pathToFileURL(resolve(path)).href);
const {loadConfig}=await load('src/server/config.ts');
const {openDatabase,ensureCorpusLoaded}=await load('src/corpus/store.ts');
const {createEngineDeps,verifyInput,PIPELINE_VERSION}=await load('src/engine/verify.ts');
const {warmUp}=await load('src/engine/retrieval/index.ts');
const cfg=loadConfig({dbPath:dir+'/cost59.sqlite',liveSearch:true});
const db=openDatabase(cfg.dbPath),corpus=ensureCorpusLoaded(db),deps=createEngineDeps(db,cfg);
if(!deps.llm.available)throw Error('No real model');
const reference=JSON.parse(readFileSync(dir+'/heldout.json','utf8')).meta;
const caseHash=hashFile(dir+'/cost59-inputs.json'),codeHash=hashFile('src/engine/verify.ts');
if(reference.corpus.snapshotId!==corpus.snapshotId||reference.verifySourceHash!==codeHash||reference.main!==cfg.modelMain||reference.fast!==cfg.modelFast||reference.provider!==deps.llm.name)throw Error('Reference configuration differs');
const prev=existsSync(output)?JSON.parse(readFileSync(output,'utf8')):null;
if(prev&&(prev.meta.caseHash!==caseHash||prev.meta.verifySourceHash!==codeHash))throw Error('Refusing to mix runs');
const meta={started:prev?.meta.started??new Date().toISOString(),workers:3,selectedFrom:[...new Set(inputs.map(e=>e.source))],selection:'Reviewed 59 unique pre-existing Polish questions, assertions and opinions, excluding incidents invented for testing, attacks, external input URLs, fault injection, attached examples and heldout-v2 duplicates; only text sent to the engine.',caseHash,verifySourceHash:codeHash,gitSha:reference.gitSha,corpus,PIPELINE_VERSION,provider:deps.llm.name,main:cfg.modelMain,fast:cfg.modelFast,verifier:deps.verifier.name,singleKey:deps.singleKey,liveSearch:cfg.liveSearch,branches:deps.branches.map(b=>b.id),warm:await warmUp(deps.branches)};
const results=new Map((prev?.results??[]).map(x=>[x.id,x]));
const pending=inputs.filter(item=>!results.has(item.id));
const log=line=>{console.log(line);appendFileSync(dir+'/cost59.log',line+'\n')};
const sum=arr=>Math.round(arr.reduce((n,v)=>n+v,0)*1e6)/1e6;
function save(complete=false){
 const rows=inputs.map(s=>results.get(s.id)).filter(Boolean);
 const out={meta:{...meta,complete,...(complete?{finished:new Date().toISOString()}:{})},count:rows.length,planned:inputs.length,costUsd:sum(rows.map(r=>r.report?.costUsd??0)),fullReports:rows.filter(r=>r.report).length,results:rows};
 writeFileSync(output+'.writing',JSON.stringify(out,null,2));renameSync(output+'.writing',output);
}
log(JSON.stringify(meta));save();let cursor=0;
async function worker(){
 while(cursor<pending.length){
 const item=pending[cursor++];const from=new Date().toISOString(),start=performance.now();let report,error;
 try{report=await verifyInput({channel:'eval',kind:'text',receivedAt:from,text:item.text},deps,{signal:AbortSignal.timeout(180000)});}
 catch(e){error=e instanceof Error?String(e.message):String(e);}
 const latencyMs=Math.round(performance.now()-start);
 results.set(item.id,{...item,from,latencyMs,...(report?{report}:{error})});save();
 log([results.size,inputs.length,item.id,report?.status,report?.mainVerdict,report?.costUsd,latencyMs,report?.models?.length??0].join(' '));
 }
}
await Promise.all([worker(),worker(),worker()]);save(true);db.close();
