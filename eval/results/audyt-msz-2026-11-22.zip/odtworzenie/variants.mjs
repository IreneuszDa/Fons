import {randomBytes} from 'node:crypto'; import {readFileSync,writeFileSync} from 'node:fs'; import {fileURLToPath} from 'node:url'; import path from 'node:path'; import {performance} from 'node:perf_hooks';
const dir=path.dirname(fileURLToPath(import.meta.url)),root=dir+'/app'; process.chdir(root);
const {serve}=await import(root+'/node_modules/@hono/node-server/dist/index.mjs');const {loadConfig}=await import(root+'/src/server/config.ts');
const {buildProductionContext,openServerDatabase}=await import(root+'/src/server/wiring.ts');const {createApp}=await import(root+'/src/server/app.ts');
const {buildCliInbound,cliAdapter}=await import(root+'/src/server/channels/cli.ts');const {handleInbound}=await import(root+'/src/server/conversation/index.ts');
for (const id of ['Jminus','Jocr','G-cli']) {
 const config=loadConfig({env:'production',dbPath:dir+'/'+id+'.db',usersPath:dir+'/'+id+'-users.json',adminPassword:randomBytes(32).toString('hex'),userIdPepper:randomBytes(32).toString('hex'),alertWebhookUrl:undefined,...(id==='Jminus'?{factCheckApiKey:'audit-invalid-credential'}:id==='Jocr'?{openaiApiKey:undefined,anthropicApiKey:undefined,mistralApiKey:undefined}:{} )});
 const db=openServerDatabase(config),ctx=buildProductionContext(config,db);
 const question=id==='Jminus'?'Czy Demagog sprawdzał, czy Wrocław był jedynym miastem z darmowymi przejazdami dla 65-latków?':id==='Jocr'?'Czy Demagog to sprawdzał?':'Czy Wrocław był jedynym miastem w Polsce, w którym 65-latkowie jeździli komunikacją miejską za darmo?';
 const start=Date.now(), t=performance.now(); let output;
 if(id==='G-cli') {
  const reply=await handleInbound(buildCliInbound(ctx,{senderId:ctx.security.pseudonymize('cli:local'),text:question}),ctx);
  output={response:{reply},rendered:cliAdapter.render(reply)};
 }else{
  const app=createApp(ctx);let srv;const port=await new Promise(ok=>{srv=serve({hostname:'127.0.0.1',port:0,fetch:app.fetch},a=>ok(a.port))});const url='http://127.0.0.1:'+port;
  const req={text:question};if(id==='Jocr')req.image={mime:'image/png',base64:readFileSync(dir+'/source.png').toString('base64')};
  const http=await fetch(url+'/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(req)});const response=await http.json();
  const elapsed=(performance.now()-t)/1000;output={http:http.status,response,elapsed};
  const rpt=response.reply?.report;if(rpt){const read=await fetch(url+'/api/report/'+rpt.token), r=await read.json();output.readback_http=read.status;output.readback_same_id=(r.report??r).id===rpt.id};
  await new Promise(ok=>srv.close(ok));
 }
 const result={id,question,started:new Date(start).toISOString(),elapsed:(performance.now()-t)/1000,...output};
 writeFileSync(dir+'/res/'+id+'.json',JSON.stringify(result));console.log(id,result.http,result.elapsed,result.response?.reply?.textPl?.slice(0,200));
 // Background warm-up may still be using the connection. Each variant uses a different sqlite file.
}
process.exit(0);
