from urllib.request import Request,build_opener,HTTPCookieProcessor
from urllib.error import HTTPError
import http.cookiejar,json,pathlib
p=pathlib.Path(__file__).resolve().parent
u='http://127.0.0.1:18843';j=build_opener(HTTPCookieProcessor(http.cookiejar.CookieJar()))
def req(method,uri,body=None):
 try:
  with j.open(Request(u+uri,method=method,data=json.dumps(body).encode() if body is not None else None,headers={'Content-Type':'application/json'}),timeout=180) as res:return res.status,json.load(res)
 except HTTPError as e:return e.code,json.loads(e.read())
a1=json.loads((p/'res/A1.json').read_text());protected=a1['response']['reply']['report']['token']
http,created=req('POST','/api/chats',{}); sid=created['chat']['id']
def say(txt):return req('POST','/api/chat',{'sessionId':sid,'text':txt})
_,r=say(a1['question']);r=r['reply']; token=r['report']['token']
assert token!=protected
_,s=say('źródła');_,w=say('Jak to sprawdziłeś?');_,d=say('Usuń moje dane')
before,_=req('GET','/api/report/'+token); _,x=say('tak'); after,_=req('GET','/api/report/'+token); orig,_=req('GET','/api/report/'+protected)
result={'own_fresh_session':http,'generated_reply':r['kind'],'cacheHit':r['report']['cacheHit'],'own_token_new':token!=protected,'sources_reply':s['reply']['kind'],'sources_in_reply':'demagog.org.pl' in s['reply']['textPl'],'why_reply':w['reply']['kind'],'deletion_requested':d['reply']['kind'],'before_confirm':before,'confirmation_result':x['reply']['kind'],'after_confirm':after,'other_report_remains':orig}
(p/'session-check.json').write_text(json.dumps(result));print(result)
