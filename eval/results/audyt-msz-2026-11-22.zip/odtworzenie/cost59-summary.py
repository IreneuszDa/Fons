import hashlib, json, math, statistics, sys
from collections import Counter
from decimal import Decimal
from pathlib import Path

d=Path(__file__).resolve().parent
files=['heldout.json','cost59.json']
sources=[json.loads((d/name).read_text()) for name in files]
meta=sources[0]['meta']
for key in ['corpus','PIPELINE_VERSION','verifySourceHash','provider','main','fast','verifier','liveSearch','branches']:
    if meta[key]!=sources[1]['meta'][key]:
        raise ValueError('Incompatible metadata: '+key)
rows=[]
for source,group in zip(files,sources):
    for item in group['results']:
        report=item.get('report')
        if not report:
            raise ValueError('Missing report, unable to aggregate its cost reliably')
        text=item.get('text') if source=='cost59.json' else item['case']['inputPreview']
        id=item.get('id') if source=='cost59.json' else item['case']['id']
        usd=Decimal(str(report['costUsd']))
        grouped=sum((Decimal(str(m['costUsd'])) for m in report['models']),Decimal(0))
        if abs(usd-grouped)>Decimal('0.000001'): raise ValueError('Report cost does not agree with model breakdown')
        rows.append({'id':id,'source':source,'textSha256':hashlib.sha256(text.encode()).hexdigest(),'usd':usd,'search':sum((Decimal(str(m['costUsd'])) for m in report['models'] if m['purpose']=='live_search'),Decimal(0)),'latency':item.get('latencyMs',item.get('run',{}).get('latencyMs')),'tokensIn':sum(m['inputTokens'] for m in report['models']),'tokensOut':sum(m['outputTokens'] for m in report['models']),'models':len(report['models']),'status':report['status'],'cache':report.get('cacheHit'),'unavailableBranches':report.get('unavailableBranches',[])})
if len(rows)!=len(set(r['textSha256'] for r in rows)):raise ValueError('Duplicate questions across selections')
x=sorted(r['latency']/1000 for r in rows);y=sorted(float(r['usd']) for r in rows)
def pct(a,p):return round(a[max(0,math.ceil(len(a)*p)-1)],6)
cost=sum(r['usd'] for r in rows)
to_usd=lambda d:float(round(d,6))
out={'complete':len(rows)==100 and all(g['meta'].get('complete') for g in sources),'planned':100,'executions':len(rows),'uniqueInputs':len({r['textSha256'] for r in rows}),'reportTotalsEqualModelCosts':True,'measuredReportCostUsd':to_usd(cost),'modelReportedSearchUsd':to_usd(sum(r['search'] for r in rows)),'reportCostExcludingSearchUsd':to_usd(cost-sum(r['search'] for r in rows)),'perQueryUsd':{'mean':round(sum(y)/len(y),6),'median':round(statistics.median(y),6),'p95NearestRank':pct(y,.95),'max':max(y)},'latencySeconds':{'mean':round(sum(x)/len(x),3),'median':round(statistics.median(x),3),'p95NearestRank':pct(x,.95),'max':round(max(x),3)},'status':dict(Counter(r['status'] for r in rows)),'cacheHits':sum(r['cache'] is True for r in rows),'reportsWithAnyUnavailable':sum(bool(r['unavailableBranches']) for r in rows),'unavailableBranchReports':dict(Counter(b for r in rows for b in r['unavailableBranches'])),'modelUseEntries':sum(r['models'] for r in rows),'tokensIn':sum(r['tokensIn'] for r in rows),'tokensOut':sum(r['tokensOut'] for r in rows),'byFile':{file:{'count':sum(r['source']==file for r in rows),'costUsd':to_usd(sum(r['usd'] for r in rows if r['source']==file))}for file in files},'metadata':{**{key:meta[key]for key in ['PIPELINE_VERSION','verifySourceHash','provider','main','fast','verifier','liveSearch','branches']},'snapshot':meta['corpus']['snapshotId']},'notes':'100 prespecified text inputs, isolated verifyInput, live network and models, no conversation shell; cost from model usage and engine rates, excludes late/unreported usage, not an invoice; p95 nearest rank; one worker for 41 and three for 59.'}
if out['complete']:(d/'cost59-plus41.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(out,ensure_ascii=False))
