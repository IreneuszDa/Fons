# Jak czytać i powtórzyć pomiar

Wyniki są zapisane w katalogu `wyniki`. Najkrótsza ścieżka do konkretnej odpowiedzi prowadzi przez `indeks.csv`, a następnie `czat-i-cli.json`, `heldout.json` lub `cost59.json`. Pola status i werdykt mają odrębne znaczenie. W raportach pytań otwartych występuje również pole `answer`. Pole koszt opisuje wycenę zarejestrowaną przez silnik. Prywatne odsyłacze do raportów i identyfikatory sesji pominięto.

## Odtworzenie

Potrzebne są Node obsługiwany przez repozytorium, Python 3, połączenie z internetem i działające rzeczywiste klucze API. Do pełnego powtórzenia są potrzebne OpenAI, Google Fact Check Tools oraz Cloud Vision. Polecenia należy wykonywać w **osobnym katalogu roboczym** repozytorium z commitem `83e42b2c1cf494c593447b5566e48e5ecb164ce0`. Zachowaj oryginalny katalog aplikacji i dane użytkowników. Do zewnętrznych API trafią pytania i materiały danej próby.

1. Rozpakuj ZIP do `.cache/pomiar-pakiet` w osobnym katalogu roboczym. Odtwórz stan plików poleceniem `patch -p1 -i .cache/pomiar-pakiet/stan-kodu.patch` w jego katalogu głównym. Przygotuj zależności według README projektu (`npm ci`, `npm run build`, opcjonalnie `npm run setup:video`). Wskaż własną konfigurację w `.env`.
2. Utwórz katalog na skrypty i ich wyniki. Wykonaj w oddzielnym katalogu roboczym poniższe polecenia. Każdą niezależną powtórkę zaczynaj w pustym katalogu pomiaru i na nowych bazach, aby uniknąć wznowienia lub wspólnej pamięci odpowiedzi.

```sh
mkdir -p .cache/pomiar/res .cache/pomiar/app/.cache
cp .cache/pomiar-pakiet/odtworzenie/* .cache/pomiar/
cp .cache/pomiar-pakiet/dowody/source.png .cache/pomiar-pakiet/dowody/source.mp3 .cache/pomiar-pakiet/dowody/earth.jpg .cache/pomiar/
cp -R src scripts data package.json tsconfig.json web-dist public .cache/pomiar/app/
ln -s "$PWD/node_modules" .cache/pomiar/app/node_modules
ln -s "$PWD/.cache/video-tools" .cache/pomiar/app/.cache/video-tools
export DOTENV_CONFIG_PATH="$PWD/.env"
```

3. Uruchom `node --import tsx .cache/pomiar/serve.mjs`. Serwer używa localhost na porcie 18843, niezależnej bazy i wyłączonego zewnętrznego odbiorcy alertów. W drugim terminalu uruchom poniższy klient HTTP. Kolejność obejmuje utworzenie sprawy H1 przed przetworzeniem H2. Skrypt klienta zapisuje odpowiedzi w katalogu `res`. Pozostaw ustawienia limitów produktu. Przy powtarzaniu wielu prób jedna za drugą zwróć uwagę na rzeczywisty status HTTP 429.

```sh
python3 .cache/pomiar/drive.py A1 A2 B C D H1 G E-kontrola Iplus Iminus H2 Jplus
python3 .cache/pomiar/drive.py F Audio
python3 .cache/pomiar/drive.py Bonus-obraz A2-ANSA Multi I-X A22-WWW
python3 .cache/pomiar/session-check.py
```

4. W terminalu z ustawionym `DOTENV_CONFIG_PATH` wykonaj `node --import tsx .cache/pomiar/variants.mjs`. Uruchomi to prawdziwą ścieżkę WWW z odrzuconym kluczem Google, ścieżkę bez klucza OCR i kanał CLI z działającym modelem. Stany tych trzech prób mają osobne pliki bazy.
5. Koszt i jakość tekstu odtworzysz poleceniami poniżej. Pierwszy skrypt wykonuje 41 prób sekwencyjnie, drugi 59 z maksymalnie trzema aktywnymi żądaniami. Każdy skrypt zapisuje wynik po zakończonym przypadku, a po wznowieniu pomija istniejące wyniki. W oryginalnym pomiarze oba zbiory były uruchomione w zbliżonym czasie. Latencja jest wrażliwa na obciążenie i stan dostawcy.

```sh
node --import tsx .cache/pomiar/run-heldout.mjs
node --import tsx .cache/pomiar/cost59.mjs
python3 .cache/pomiar/cost59-summary.py
```

Część pytań jest zależna od dnia, a publikacje i indeksy internetowe zmieniają się. Powtórzenie procedury nie gwarantuje identycznych odpowiedzi. Oryginalne wejścia i odpowiedzi zachowano na potrzeby audytu. Pochodzenie plików multimedialnych opisuje `dowody/pochodzenie.json`. Plik `sha256.json` obejmuje wszystkie pozostałe pliki pakietu.
