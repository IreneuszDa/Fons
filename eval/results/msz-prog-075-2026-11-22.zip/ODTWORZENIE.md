# Odtworzenie pomiaru Fons

Katalog `pomiary/` zawiera cztery niezależnie zainicjowane serie po 100 stałych pytań i 30 dodatkowych jawnych tekstów oraz punkt odniesienia v32. Plik `metryki.json` w każdej serii obejmuje również wszystkie 68 jawnych tekstów. Każdy raport zapisuje treść wejścia, klucz, odpowiedź, źródła, koszt i czas. Kwoty są oszacowaniami silnika według skonfigurowanego cennika.

Żeby przeliczyć zapisane odpowiedzi, rozpakuj archiwum i zainstaluj zależności projektu w katalogu `aplikacja` przy użyciu Node 22 i `npm ci`. Z katalogu archiwum uruchom polecenie dla wybranej serii (a, b, c lub d).

```sh
cd aplikacja
node --import tsx ../narzedzia/score.mjs . ../pomiary/d/live100.json ../pomiary/d/live30.json ../przeliczone-d.json
```

Żeby uruchomić silnik na nowo, zacznij od czystej kopii katalogu `aplikacja`. To wersja serii A. Dla B, C albo D skopiuj do niej wszystkie pliki z odpowiedniego katalogu zmian, z zachowaniem ich położenia względem źródeł. Każdy zestaw zmian odnosi się do A. Dostęp do płatnych dostawców wymaga własnej konfiguracji zgodnej z `.env.example`. W pomiarze ustawiono wyszukiwanie na żywo i korzystano z modelu głównego gpt-6.2-sol oraz szybkiego gpt-6-luna. Do wyszukiwania wektorowego potrzebne są lokalne wagi Xenova/multilingual-e5-small zgodne z manifestem w `data/embeddings`. Pełny audyt cytatów wymaga dodatkowo kopii dokumentów wydawców w cache importera.

Dla czystego przebiegu użyj nowych katalogów wyjściowych.

```sh
node --env-file=.env --import tsx eval/real-text.mjs ../nowa-seria-100
node --env-file=.env --import tsx ../narzedzia/dev-extension.mjs . ../nowa-seria-30
node --import tsx ../narzedzia/score.mjs . ../nowa-seria-100/live100.json ../nowa-seria-30/live30.json ../nowe-metryki.json
```

Każdy proces używa trzech równoległych wykonawców i własnej bazy SQLite. Dostawcy mogą zwrócić inny odczyt lub wynik wyszukiwania przy powtórzeniu. Skróty SHA-256 wszystkich plików wewnątrz pakietu zapisano w `SHA256SUMS`.
