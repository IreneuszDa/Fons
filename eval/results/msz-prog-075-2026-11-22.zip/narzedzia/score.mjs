import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
const [project,selection,extension,output] = process.argv.slice(2).map(s=>path.resolve(s));
const read = file=>JSON.parse(readFileSync(file,'utf8'));
const base=read(selection), extra=read(extension);
if (!base.meta.complete || !extra.meta.complete || base.rows.length!==100 || extra.rows.length!==30) throw Error('Niekompletna seria');
for(const key of ['codeSha256','pipeline','main','fast','provider','singleKey']) if(base.meta[key]!==extra.meta[key])throw Error('Różne konfiguracje: '+key);
if(base.meta.corpus.snapshotId!==extra.meta.corpus.snapshotId)throw Error('Różne wersje korpusu');
const {confusionMatrix,verdictPairs,f1FromConfusion,endToEnd,latency,cost,abstention,citationCoverage}=await import(pathToFileURL(path.join(project,'eval/metrics.ts')));
const dev=base.rows.filter(r=>r.case.dataset==='dev').concat(extra.rows);
if(dev.length!==68 || new Set(dev.map(r=>r.case.id)).size!==68)throw Error('Zły podział dev');
function metrics(rows){
 const outcomes=rows.map(row=>({case:row.case,runs:[row.run]})),pairs=verdictPairs(outcomes),confusion=confusionMatrix(pairs);
 return {entries:rows.length,withVerdictKey:pairs.length,correct:rows.filter(r=>r.correct).length,confusion,f1:f1FromConfusion(confusion),endToEnd:endToEnd(outcomes),latency:latency(outcomes),cost:cost(outcomes),abstention:abstention(outcomes),citations:citationCoverage(outcomes),cacheHits:rows.filter(r=>r.report?.cacheHit).length,
 open:rows.filter(r=>!r.case.expected.verdict).map(r=>({id:r.case.id,ok:r.correct})),wrong:rows.filter(r=>!r.correct).map(r=>({id:r.case.id,question:r.case.inputPreview,expected:r.case.expected.verdict??null,actual:r.run.mainVerdict,summary:r.report?.summaryPl}))};
}
const keyFiles=['eval/metrics.ts','eval/real-text.mjs','eval/real-text-selection.json','eval/cases/dev.jsonl','eval/cases/heldout.jsonl','eval/cases/heldout-v2.jsonl'];
const hashes=Object.fromEntries(keyFiles.map(f=>[f,createHash('sha256').update(readFileSync(path.join(project,f))).digest('hex')]));
const result={meta:base.meta,hashes,originalDev:metrics(base.rows.filter(r=>r.case.dataset==='dev')),extraDev:metrics(extra.rows),allDev:metrics(dev),heldout:metrics(base.rows.filter(r=>r.case.dataset==='heldout')),heldoutV2:metrics(base.rows.filter(r=>r.case.dataset==='heldout-v2')),original100:metrics(base.rows),all130:metrics([...base.rows,...extra.rows])};
writeFileSync(output,JSON.stringify(result,null,2));
for(const [key,row] of Object.entries(result).slice(2))console.log(key,row.entries,row.correct,row.withVerdictKey,row.f1.macroF1);
