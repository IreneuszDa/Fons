# Zakres jawnej ewaluacji tekstowej Fons

Sekcja 6 PDF konkursowego (s. 7–9) określa minimum 30 przypadków referencyjnych, scenariusze A–J i próg macro-F1 ≥ 0,75 na obsługiwanych klasach w zestawie jawnym. Ukryty wynik ma charakter porównawczy. Plik Word zawiera 11 przykładów dla 10 scenariuszy, w tym dwa przykłady A oraz pola na konkretne osoby, daty, materiały i adresy. Żadne z 11 wejść tabeli Worda nie występuje w całości dosłownie w dev.jsonl. Pokrycie tych przykładów i pokrycie danych projektu wymagają osobnych pomiarów.

| Zakres | Liczba przypadków | Z oczekiwanym werdyktem do F1 | Pytania otwarte |
|---|---:|---:|---:|
| Teksty dev w manifeście 100 zapytań | 38 | 34 | 4 |
| Pozostałe zwykłe teksty dev | 30 | 29 | 1 |
| Wszystkie zwykłe teksty dev | 68 | 63 | 5 |

Wśród 38 jest 22 przypadków scenariusza A, 6 B, 3 C i 7 X (dodatkowa kategoria projektu). Uzupełnienie obejmuje 15 A, 1 B, 6 D, 2 G, 2 H, 1 I i 3 X. Wszystkie 68 wejść można podać do produkcyjnego silnika bez podstawiania źródeł lub odpowiedzi usługodawców. Wśród 63 etykiet jest 21 potwierdzeń, 19 fałszów, 11 braków dowodów, 8 ocen wprowadzających w błąd i 4 przypadki niepodlegające ocenie. Wynik dla 63 trzeba obliczyć ze wspólnej macierzy pomyłek wszystkich przypadków.

Pełny dev.jsonl ma 84 pozycje. Pozostałe 16 to 3 teksty testujące odporność na instrukcje, 3 wymuszone awarie (2 tekstowe i 1 obraz bez pliku) oraz 10 adresów stron. Trzy wejścia URL, L01, L03 i L05, wskazują dostępne publiczne publikacje MSWiA i NATO. Można je sprawdzić bez pośrednictwa dotychczasowego mechanizmu zastępującego odpowiedź przez plik HTML. Siedem pozostałych adresów zdefiniowano na domenie fixture.prawdowid.test lub pod ścieżką testową. Trzy teksty testujące odporność można podać bez zmiany i ocenić osobną miarą odporności. Awaria wymaga odrębnego protokołu, który w sposób kontrolowany powoduje rzeczywistą niedostępność usługi.

Pojedyncze wywołanie verifyInput mierzy odpowiedź na teksty G01/G02 i H01/H02. Sprawdzenie zgodności WWW z komunikatorem wymaga obu kanałów, a deduplikacja H wymaga zapisania dwóch kolejnych zgłoszeń i sprawdzenia tożsamości sprawy. Kod testów HTTP w eval/acceptance.ts zawiera te odrębne asercje. Wszystkie teksty nie zastępują próby prawdziwego obrazu, URL, awarii i pełnego przebiegu kanałowego.

W obu częściach tekstowych identyczne definicje etykiet i metryk pochodzą z eval/cases/dev.jsonl oraz eval/metrics.ts. Uzupełnienie 30 sprawdza rozłączność od pierwszych 38 i identyczność treści z utrwalonymi hashami. Wyniki tych zbiorów opisują testy projektu, których treść była znana zespołowi.
