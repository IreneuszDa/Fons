import type { CorpusRecord } from "../shared/contracts";
import { fold } from "./retrieval/stem";
import { foldForMatch, MONTHS_PL } from "./text";

// Only an unqualified round, election type, optional place/year and the occurrence date.
// A claim about turnout, the winner or the legality of the vote needs a separate finding.
const roundOnDay = new RegExp(
  String.raw`^(?:czy )?(?:pierwsza|druga|i|ii|1|2) tura (?:polskich )?wyborow (?:prezydenckich|parlamentarnych|samorzadowych|prezydenta (?:rp|rzeczypospolitej polskiej))`
  + String.raw`(?: (?:w|we|na) [a-z]+)?(?: w (?:roku )?\d{4}(?: r| roku)?)? (?:nie )?odbyla sie (?:w dniu )?\d{1,2} (?:`
  + MONTHS_PL.map(foldForMatch).join("|") + String.raw`)(?: \d{4}(?: r| roku)?)?$`, "u",
);
export function asksForElectionRoundDate(text: string): boolean {
  return roundOnDay.test(foldForMatch(text));
}

/** A query about winning an election as a whole, as opposed to winning one round. */
export function asksForElectionWinner(query: string): boolean {
  const s = fold(query);
  return /\b(?:wybor\w*|elekcj\w*|election\w*)\b/.test(s)
    && /\b(?:wygr\w*|zwycie\w*|wybran\w*|winner|won|elected)\b/.test(s)
    && !/\b(?:pierwsz\w*|1\.?|i)\s+tur\w*|\bfirst.round\b/.test(s);
}

/** Classify only explicit statements in the body. A bulletin title may occur on every page of the results. */
export function electionResultStage(record: CorpusRecord): "elected" | "runoff_pending" | undefined {
  if (record.role !== "tresc" || record.level !== 1 || !/\b(?:wybor\w*|election\w*)\b/.test(fold(record.title))) return;
  const s = fold(record.text).replace(/\s+/g, " ");
  if (/\b(?:zostal[ai]? wybran[ay]|wybran[ay] zostal[ai]?|(?:was|has been) elected)\b/.test(s)) return "elected";
  if (/\b(?:przeprowadzone zostanie ponowne glosowanie|odbedzie sie (?:ponowne glosowanie|druga tura)|(?:a |the )?runoff will be held)\b/.test(s)) return "runoff_pending";
}
